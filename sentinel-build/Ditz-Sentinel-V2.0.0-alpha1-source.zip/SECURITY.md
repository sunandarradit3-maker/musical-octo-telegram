# Sentinel V2 Security Notes

## Secrets

Never commit or ship any of the following in the APK or repository:

- Google OAuth client secret
- PostgreSQL `DATABASE_URL`
- `SESSION_SECRET`
- raw owner PIN or `OWNER_PIN_HASH`
- threat-feed ECDSA private key
- production signing keystore/password

The Android app contains only the backend URL, public threat-feed verification key, and optional release signer certificate pin.

## Owner access

Owner access is two-step:

1. Google identity must resolve to the server-configured owner email.
2. A second owner PIN must verify against an scrypt hash.

PIN attempts are rate-limited with a database-backed lock. Successful elevation issues a separate 15-minute owner token. Android deliberately does not persist that owner token.

## Google login callback

The custom Android callback scheme is treated as an untrusted transport. The app generates a random verifier before login and sends only its SHA-256 challenge to the backend. The backend binds the one-time login code to that challenge. A caller that intercepts the callback code still cannot exchange it without the original verifier.

For a later production-hardening release, Android App Links with a verified HTTPS domain can replace the custom scheme.

## Threat intelligence

Remote indicators are only trusted after ECDSA P-256 signature verification. Signature failure rejects the entire update. The private key must remain only on the backend/deployment secret store.

## Network isolation

The V2 VPN service is a per-app drop tunnel. It does not decrypt TLS and does not forward packet contents to a server. The Android VPN consent dialog is required before first activation.

## Reporting vulnerabilities

Do not include real user tokens, PINs, payment credentials, private APKs, or database dumps in bug reports. Reproduce with test accounts and sanitized reports whenever possible.
