# Sentinel V2 Architecture

## Trust zones

### 1. On-device security zone
The scanner, rules engine, package baseline, security timeline, device-integrity checks, link checks, trusted-app decisions, and saved scan report stay on-device. The local WebView cannot make network requests (`setBlockNetworkLoads(true)` plus CSP `connect-src 'none'`); all Android/API actions cross the explicit `Sentinel` Java bridge.

### 2. Entitlement/API zone
The backend handles Google identity, access/refresh sessions, VIP entitlement, payment queue state, owner actions, and signed threat-feed delivery. It never needs an APK or local scan report to perform those jobs.

### 3. Owner zone
Owner endpoints require an owner-elevation token, not only a normal session. Elevation requires the verified owner Google role and the scrypt-protected second PIN.

## Local data flow

```text
PackageManager
   │
   ├─ permissions / services / installer / signer
   ├─ base + split APK paths ──> bounded hashing
   │
   └─ baseline compare
          │
          v
      Rules Engine ──> risk findings
          │
          ├─ local IoCs
          └─ verified signed IoCs
          │
          v
    latest-v2.json + baseline-v2.json + history-v2.json
```

A risk score is a review priority, not a malware verdict. Only known-indicator matches are displayed as threat matches.

## Signed threat feed

```text
backend/data/threats.json
        │
        v
ECDSA P-256 private key (server secret)
        │ sign SHA-256
        v
{ payload(base64), signature(base64) }
        │ HTTPS
        v
Android bundled public key
        │ verify
        ├─ invalid -> reject entire feed
        └─ valid   -> replace in-memory remote IoCs + cache envelope
```

## Google login

```text
Android: random verifier
        │ SHA-256
        v
challenge -> /api/auth/google/start -> Google OAuth
                                      │
                                      v
                          /api/auth/google/callback
                                      │
                           verified Google identity
                                      │
                   one-time code bound to challenge
                                      │ custom URI
                                      v
Android receives code + original verifier
        │
        v
/api/auth/exchange verifies SHA-256(verifier)==challenge
        │
        v
15 min access token + rotating 30 day refresh token
```

The session tokens are encrypted at rest on Android with an AES/GCM key held in Android Keystore.

## Manual VIP payment queue

The backend, not the client, selects plan price and duration. The client submits only plan code, method, and a short sender/reference field. The server creates an immutable amount snapshot on the request. Owner approval runs in a transaction and extends `vip_until` from the later of `now()` or the current entitlement date.

## Per-app isolation

Sentinel requests Android VPN consent. `IsolationVpnService.Builder.addAllowedApplication(packageName)` routes only the selected package into a local TUN with default IPv4/IPv6 routes. Sentinel reads and drops those packets. No other app is routed through that tunnel.
