# Engineering research and boundaries

Sentinel V2 is designed around Android's application sandbox rather than pretending a normal third-party app has iOS/OS-kernel privileges. The useful goal is stricter visibility, integrity checks, signed intelligence, explicit isolation, and clear recovery controls within APIs Android actually exposes.

## Threat classes covered by V2 signals

| Threat class | Useful observable signals in V2 | Important limitation |
|---|---|---|
| Spyware / stalkerware | known hashes/domains, Accessibility, notification access, sensitive permission combinations, installer source | cannot read another app's private database or prove intent from permissions alone |
| Account/OTP theft | Accessibility + overlay + SMS/notification combinations | heuristics prioritize review; they are not a malware verdict |
| Repackaged/fake apps | signing certificate, signer drift, source/installer, package identity | visual cloning alone may need human review |
| Sideload/dropper activity | install source, REQUEST_INSTALL_PACKAGES, package-change timeline | cannot inspect every downloaded payload before another installer acts |
| Network exfiltration | explicit per-app network kill switch | V2 does not decrypt TLS or run a full IDS |
| Root/system compromise | Verified Boot properties when readable, SELinux, common root artifacts, patch age | a sufficiently privileged compromise can hide from an ordinary app |
| Phishing links | bundled/signed domain IOCs, Punycode, IP URL, HTTP, user-info, shortener hints | no indicator match is never a guarantee that a site is safe |

## Primary references used for the design

- Android Application Sandbox: https://source.android.com/docs/security/app-sandbox
- Package visibility: https://developer.android.com/training/package-visibility
- Google Play `QUERY_ALL_PACKAGES` policy: https://support.google.com/googleplay/android-developer/answer/10158779
- Android `VpnService`: https://developer.android.com/reference/android/net/VpnService
- `VpnService.Builder.addAllowedApplication`: https://developer.android.com/reference/android/net/VpnService.Builder#addAllowedApplication(java.lang.String)
- Foreground service types: https://developer.android.com/develop/background-work/services/fgs/service-types
- JobScheduler: https://developer.android.com/reference/android/app/job/JobInfo.Builder
- WebView native bridge risks: https://developer.android.com/privacy-and-security/risks/insecure-webview-native-bridges
- ESET public ProSpy/ToSpy research used only for the small bundled sample IoC set: https://www.welivesecurity.com/en/eset-research/new-spyware-campaigns-target-privacy-conscious-android-users-uae/

No malware sample is included in the project. Public indicators are used as deterministic test/research data only.

## Production gates

Before commercial distribution, test on physical Android devices/ROMs, measure false positives against a representative corpus, establish an audited threat-intelligence update process, protect release/signing keys, perform backend/API penetration testing, and complete distribution-store permission declarations. Independent validation matters more than the number of features in the UI.
