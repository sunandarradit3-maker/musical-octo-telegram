# Validation checklist

The repository packaging process runs these local checks:

- Pure-Java deterministic Rules tests, including hash known-answer tests, size bounds, link parsing, local IOCs, and remote-feed behavior.
- JavaScript syntax checks for Android UI and backend server files.
- XML parse checks for Android manifest/resources.
- Secret leakage scan for the configured owner email, raw owner PIN, and threat-feed private-key PEM marker in the distributable source tree.
- SHA-256 manifest for generated deliverables.

Not validated in this container unless an Android SDK and npm dependencies are available:

- Full Android `assembleDebug`/`assembleRelease` compile.
- Full Next.js production build and live PostgreSQL migration.
- Google OAuth against production credentials.
- VpnService behavior on a physical Android device.

These are release gates, not optional claims. Do not advertise a feature as production-verified until the corresponding integration test has passed.
