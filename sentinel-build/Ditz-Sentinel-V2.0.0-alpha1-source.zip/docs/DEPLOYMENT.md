# Sentinel V2 Deployment

## 1. PostgreSQL

Create a PostgreSQL database and set `DATABASE_URL` privately. Run:

```bash
cd backend
npm install
npm run migrate
```

The migration creates users, one-time login codes, rotating refresh tokens, payment requests, owner PIN lock state, and an audit log.

## 2. Google OAuth

Create a Google OAuth Web application. Configure this exact authorized redirect URI:

```text
https://YOUR-BACKEND/api/auth/google/callback
```

Set `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` on the backend. The Android client never receives the client secret.

## 3. Server secrets

Configure:

- `SESSION_SECRET`: at least 32 random bytes.
- `OWNER_EMAIL`: exact Google email allowed to become the OWNER role.
- `OWNER_PIN_HASH`: generated with `npm run hash-pin`; never store the raw PIN.
- `THREAT_FEED_PRIVATE_KEY_B64`: base64 of the full PEM private key bytes.

## 4. Payment config

Set integer rupiah values for `VIP_1M_PRICE` and `VIP_3M_PRICE`. Until configured, the backend refuses new payment requests rather than inventing a price.

Set `PAYMENT_EWALLET_NUMBER`, `PAYMENT_QRIS_NAME`, and optionally `SUPPORT_WHATSAPP`.

Payment confirmation remains owner-reviewed. The UI truthfully says "antrean verifikasi" while pending.

## 5. Deploy backend on Vercel

Use `backend/` as the Vercel project root. Add every secret through Vercel Environment Variables, not committed `.env` files. After deployment, confirm:

```text
GET https://YOUR-BACKEND/api/health
```

Then set the deployed HTTPS origin in `app/src/main/res/values/config.xml` as `sentinel_api_base`.

## 6. Android release

Before release:

- Target/compile SDK 36.
- Build and sign with your production keystore.
- Set `sentinel_expected_signer_sha256` to your release certificate SHA-256 if you want self-integrity pinning.
- Verify Google login, callback exchange, token refresh, payment submission, owner PIN lockout, approve/reject, VIP expiry, VPN consent, per-app isolation, periodic scans, reboot behavior, and signed threat feed on physical devices from several vendors.
- Prepare the required store declaration for broad package visibility if distributing through Google Play.

## 7. Threat-feed updates

Edit `backend/data/threats.json` only from vetted indicators. Keep the payload small and explainable. Do not add a domain or file hash merely because it is "suspicious"; threat entries should have a defensible source and label.
