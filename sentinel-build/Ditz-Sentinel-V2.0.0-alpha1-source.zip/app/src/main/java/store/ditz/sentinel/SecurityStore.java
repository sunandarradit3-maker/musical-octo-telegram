package store.ditz.sentinel;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.AtomicFile;
import org.json.*;
import java.io.*;
import java.util.*;

/** Local state for trust decisions, scan baselines and an append-only bounded security timeline. */
public final class SecurityStore {
 private static final String PREFS="sentinel_v2";
 private static final String TRUSTED="trusted_packages";
 private static final String MODE="protection_mode";
 private static final int MAX_HISTORY=100;
 private final Context c;
 private final SharedPreferences prefs;

 public SecurityStore(Context context){c=context.getApplicationContext();prefs=c.getSharedPreferences(PREFS,0);}

 public boolean isTrusted(String pkg){Set<String>s=prefs.getStringSet(TRUSTED,Collections.emptySet());return s!=null&&s.contains(pkg);}
 public synchronized void setTrusted(String pkg,boolean on){
  Set<String> s=new HashSet<>(prefs.getStringSet(TRUSTED,Collections.emptySet()));
  if(on)s.add(pkg);else s.remove(pkg);
  prefs.edit().putStringSet(TRUSTED,s).apply();
  event(on?"trusted":"untrusted",pkg,pkg,on?"Ditandai tepercaya oleh pengguna":"Status tepercaya dicabut","info");
 }
 public JSONArray trusted(){JSONArray a=new JSONArray();for(String p:prefs.getStringSet(TRUSTED,Collections.emptySet()))a.put(p);return a;}

 public String mode(){String m=prefs.getString(MODE,"standard");return Arrays.asList("standard","strict","lockdown").contains(m)?m:"standard";}
 public void mode(String m){if(!Arrays.asList("standard","strict","lockdown").contains(m))return;prefs.edit().putString(MODE,m).apply();event("mode","",m,"Mode proteksi diubah ke "+m,"info");}

 private File baselineFile(){return new File(c.getFilesDir(),"baseline-v2.json");}
 private File historyFile(){return new File(c.getFilesDir(),"history-v2.json");}

 private static String read(File f,String fallback){try(InputStream in=new FileInputStream(f)){ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)b.write(buf,0,n);return b.toString("UTF-8");}catch(Exception e){return fallback;}}
 private static void write(File f,String value)throws Exception{
  AtomicFile a=new AtomicFile(f);FileOutputStream out=null;
  try{out=a.startWrite();out.write(value.getBytes("UTF-8"));a.finishWrite(out);}catch(Exception e){if(out!=null)a.failWrite(out);throw e;}
 }

 public synchronized JSONObject baseline(){try{return new JSONObject(read(baselineFile(),"{}"));}catch(Exception e){return new JSONObject();}}

 /** Compare against previous successful deep-scan baseline. Does not mutate baseline. */
 public synchronized String baselineState(String pkg,long version,String signer){
  try{
   JSONObject old=baseline().optJSONObject(pkg);if(old==null)return "new";
   String oldSigner=old.optString("signer","");
   if(!oldSigner.isEmpty()&&!signer.isEmpty()&&!oldSigner.equalsIgnoreCase(signer))return "signer_changed";
   if(old.optLong("version",version)!=version)return "version_changed";
   return "unchanged";
  }catch(Exception e){return "unknown";}
 }

 /** Commit only a completed deep scan. Failed/incomplete individual rows are skipped. */
 public synchronized void commitBaseline(JSONObject report){
  if(report==null||!report.optBoolean("deep",false))return;
  try{
   JSONObject next=new JSONObject();JSONArray rows=report.optJSONArray("results");if(rows==null)return;
   for(int i=0;i<rows.length();i++){
    JSONObject r=rows.optJSONObject(i);if(r==null||r.has("error"))continue;
    String pkg=r.optString("pkg","");if(pkg.isEmpty())continue;
    JSONArray certs=r.optJSONArray("certificates");String signer=certs!=null&&certs.length()>0?certs.optString(0,""):"";
    next.put(pkg,new JSONObject().put("version",r.optLong("version",0)).put("signer",signer).put("label",r.optString("label",pkg)).put("seen",report.optLong("time",System.currentTimeMillis())));
   }
   write(baselineFile(),next.toString());
  }catch(Exception ignored){}
 }

 public synchronized void event(String type,String pkg,String label,String detail,String severity){
  try{
   JSONArray old=history();JSONArray next=new JSONArray();
   JSONObject e=new JSONObject().put("time",System.currentTimeMillis()).put("type",type).put("pkg",pkg==null?"":pkg).put("label",label==null?"":label).put("detail",detail==null?"":detail).put("severity",severity==null?"info":severity);
   next.put(e);
   for(int i=0;i<old.length()&&next.length()<MAX_HISTORY;i++)next.put(old.get(i));
   write(historyFile(),next.toString());
  }catch(Exception ignored){}
 }
 public synchronized JSONArray history(){try{return new JSONArray(read(historyFile(),"[]"));}catch(Exception e){return new JSONArray();}}
 public synchronized void resetBaseline(){
  try{File f=baselineFile();if(f.exists())f.delete();}catch(Exception ignored){}
  event("baseline_reset","","Baseline reset","Baseline signer/version dihapus oleh owner; deep scan berikutnya akan membentuk baseline baru","info");
 }
 public synchronized void clearHistory(){try{File f=historyFile();if(f.exists())f.delete();}catch(Exception ignored){}}

}
