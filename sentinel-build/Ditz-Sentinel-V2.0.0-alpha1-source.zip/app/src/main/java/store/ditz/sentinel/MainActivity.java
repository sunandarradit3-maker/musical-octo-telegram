package store.ditz.sentinel;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.net.VpnService;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import org.json.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Sentinel V2 shell. The WebView only serves packaged assets; all privileged operations remain native.
 * Network/API calls never run on the WebView thread.
 */
public final class MainActivity extends Activity {
 private WebView web;
 private final ExecutorService worker=Executors.newSingleThreadExecutor();
 private final AtomicBoolean busy=new AtomicBoolean(false);
 private ApiClient api;
 private SecurityStore security;
 private ThreatFeed threatFeed;
 private volatile boolean uiReady=false;
 private Uri pendingAuth;
 private String pendingSharedLink;
 private String pendingVpnPackage;

 private static final String ORIGIN="https://sentinel.invalid/";
 private static final int PICK=10, EXPORT=11, VPN=12;

 @Override public void onCreate(Bundle state){super.onCreate(state);
  api=new ApiClient(this);security=new SecurityStore(this);threatFeed=new ThreatFeed(this);
  threatFeed.loadCached();
  web=new WebView(this);web.setBackgroundColor(0xff0b1412);setContentView(web);
  web.setOnApplyWindowInsetsListener((v,in)->{v.setPadding(in.getSystemWindowInsetLeft(),in.getSystemWindowInsetTop(),in.getSystemWindowInsetRight(),in.getSystemWindowInsetBottom());return in;});
  WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(false);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setSupportMultipleWindows(false);s.setJavaScriptCanOpenWindowsAutomatically(false);s.setBlockNetworkLoads(true);
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView w,WebResourceRequest r){return true;}
   @Override public WebResourceResponse shouldInterceptRequest(WebView w,WebResourceRequest r){
    String u=r.getUrl().toString();String file=u.startsWith(ORIGIN)?u.substring(ORIGIN.length()):"";
    if(!Arrays.asList("index.html","style.css","app.js","qris.jpg").contains(file))return blocked();
    try{
     Map<String,String> headers=new HashMap<>();
     headers.put("Content-Security-Policy","default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'none'; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'");
     headers.put("X-Content-Type-Options","nosniff");
     String mime=file.endsWith(".css")?"text/css":file.endsWith(".js")?"application/javascript":file.endsWith(".jpg")?"image/jpeg":"text/html";
     return new WebResourceResponse(mime,file.endsWith(".jpg")?null:"UTF-8",200,"OK",headers,getAssets().open("ui/"+file));
    }catch(Exception e){return blocked();}
   }
   private WebResourceResponse blocked(){return new WebResourceResponse("text/plain","UTF-8",403,"Blocked",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));}
  });
  web.addJavascriptInterface(new Bridge(),"Sentinel");
  captureIntent(getIntent());
  web.loadUrl(ORIGIN+"index.html");
 }

 @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);captureIntent(intent);if(uiReady)flushPendingIntent();}
 private void captureIntent(Intent intent){
  if(intent==null)return;
  Uri data=intent.getData();if(data!=null&&"ditzsentinel".equalsIgnoreCase(data.getScheme())&&"auth".equalsIgnoreCase(data.getHost()))pendingAuth=data;
  if(Intent.ACTION_SEND.equals(intent.getAction())&&"text/plain".equals(intent.getType())){String x=intent.getStringExtra(Intent.EXTRA_TEXT);if(x!=null&&!x.trim().isEmpty())pendingSharedLink=x.trim();}
 }
 private void flushPendingIntent(){
  final Uri auth=pendingAuth;pendingAuth=null;
  if(auth!=null)worker.submit(()->{try{JSONObject account=api.exchangeCallback(auth);emit("account",account==null?JSONObject.NULL:account);emit("authMessage",JSONObject.quote("Login Google berhasil."));syncRemoteState();}catch(Exception e){error("Login gagal: "+safe(e));}});
  if(pendingSharedLink!=null){String x=pendingSharedLink;pendingSharedLink=null;emit("sharedLink",JSONObject.quote(x));}
 }

 private void emit(String event,Object value){if(web==null)return;runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())web.evaluateJavascript("if(typeof window.receive==='function')window.receive("+JSONObject.quote(event)+","+String.valueOf(value)+")",null);});}
 private void error(String message){emit("error",JSONObject.quote(message));}
 private static String safe(Exception e){String m=e.getMessage();return m==null||m.trim().isEmpty()?"operasi tidak dapat diselesaikan":m;}

 private void localStatus(){
  try{
   String saved=Scanner.load(this);Object parsed="null".equals(saved)?JSONObject.NULL:new JSONTokener(saved).nextValue();
   JSONObject feed=threatFeed.loadCached();
   emit("status",new JSONObject()
    .put("monitor",ScanJob.enabled(this))
    .put("audit",new Scanner(this).audit())
    .put("saved",parsed)
    .put("signatures",Rules.IOC.size())
    .put("threatFeed",feed)
    .put("notifications",((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).areNotificationsEnabled())
    .put("isolation",IsolationVpnService.status(this))
    .put("history",security.history())
    .put("mode",security.mode())
    .put("trusted",security.trusted())
    .put("apiConfigured",api.configured())
    .put("account",api.accountCached()==null?JSONObject.NULL:api.accountCached()));
  }catch(Exception e){error("Status perangkat tidak dapat dibaca.");}
 }
 private void syncRemoteState(){
  if(!api.configured()){try{emit("remote",new JSONObject().put("configured",false));}catch(Exception ignored){}return;}
  worker.submit(()->{
   try{
    JSONObject out=new JSONObject().put("configured",true);
    try{out.put("config",api.config());}catch(Exception e){out.put("configError",safe(e));}
    try{JSONObject a=api.me();out.put("account",a==null?JSONObject.NULL:a);if(a!=null)emit("account",a);}catch(ApiClient.ApiException e){if(e.status!=401)out.put("accountError",safe(e));}catch(Exception e){out.put("accountError",safe(e));}
    try{if(api.accountCached()!=null)out.put("payments",api.payments());}catch(Exception e){out.put("paymentsError",safe(e));}
    emit("remote",out);
   }catch(Exception e){error("Status backend tidak dapat dibaca.");}
  });
 }
 private boolean entitled(){return api.isVipCached();}
 private void requireEntitled(Runnable action){if(entitled()){action.run();return;}error("Fitur ini tersedia untuk akun VIP atau owner.");}

 public final class Bridge {
  @JavascriptInterface public void ready(){uiReady=true;localStatus();syncRemoteState();flushPendingIntent();}
  @JavascriptInterface public void refresh(){localStatus();syncRemoteState();}

  @JavascriptInterface public void scan(boolean deep){if(!busy.compareAndSet(false,true)){error("Scan lain masih berjalan.");return;}
   worker.submit(()->{try{JSONObject r=new Scanner(MainActivity.this).scan(deep,(done,total,label)->{try{emit("progress",new JSONObject().put("done",done).put("total",total).put("label",label));}catch(Exception ignored){}});Scanner.save(MainActivity.this,r);emit("report",r);}catch(Exception e){error("Scan tidak selesai. Hasil sebelumnya tetap disimpan.");}finally{busy.set(false);emit("idle","true");localStatus();}});
  }

  @JavascriptInterface public void pick(){runOnUiThread(()->{if(busy.get()){error("Tunggu scan selesai.");return;}Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);launchFor(i,PICK);});}
  @JavascriptInterface public void export(){runOnUiThread(()->{if("null".equals(Scanner.load(MainActivity.this))){error("Belum ada laporan untuk diekspor.");return;}launchFor(new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/json").putExtra(Intent.EXTRA_TITLE,"Ditz-Sentinel-V2-report.json").addCategory(Intent.CATEGORY_OPENABLE),EXPORT);});}
  @JavascriptInterface public void monitor(boolean on){runOnUiThread(()->{if(on)new AlertDialog.Builder(MainActivity.this).setTitle("Aktifkan Watchtower?").setMessage("Sentinel akan menjadwalkan pemeriksaan lokal berkala dan setelah perubahan aplikasi. Android tetap menentukan waktu eksekusi dan dapat menundanya untuk hemat baterai.").setNegativeButton("Batal",(d,w)->localStatus()).setPositiveButton("Aktifkan",(d,w)->{if(!ScanJob.schedule(MainActivity.this,true))error("Android menolak penjadwalan.");if(Build.VERSION.SDK_INT>=33)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},30);localStatus();}).show();else{ScanJob.schedule(MainActivity.this,false);localStatus();}});}

  @JavascriptInterface public void settings(String key){runOnUiThread(()->{
   Intent i;switch(key){
    case "accessibility":i=new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);break;
    case "notifications":i=new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);break;
    case "overlay":i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));break;
    case "install":i=new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+getPackageName()));break;
    case "security":i=new Intent(Settings.ACTION_SECURITY_SETTINGS);break;
    case "vpn":i=new Intent(Settings.ACTION_VPN_SETTINGS);break;
    default:i=new Intent(Settings.ACTION_SETTINGS);
   }launch(i);
  });}
  @JavascriptInterface public void app(String pkg){runOnUiThread(()->{try{getPackageManager().getPackageInfo(pkg,0);launch(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+pkg)));}catch(Exception e){error("Aplikasi sudah tidak tersedia.");}});}
  @JavascriptInterface public void reputation(String hash){if(hash==null||!hash.matches("[a-f0-9]{64}"))return;runOnUiThread(()->new AlertDialog.Builder(MainActivity.this).setTitle("Cari hash di VirusTotal?").setMessage("Browser akan mengirim hash SHA-256 ini ke VirusTotal. File APK tidak diunggah oleh Sentinel.").setNegativeButton("Batal",null).setPositiveButton("Buka",(d,w)->launch(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.virustotal.com/gui/file/"+hash)))).show());}
  @JavascriptInterface public void link(String url){if(url==null||url.length()>4096){error("Tautan terlalu panjang.");return;}emit("link",new JSONArray(Rules.link(url)));}

  @JavascriptInterface public void googleLogin(){worker.submit(()->{try{String url=api.beginGoogleLogin();runOnUiThread(()->launch(new Intent(Intent.ACTION_VIEW,Uri.parse(url))));}catch(Exception e){error(safe(e));}});}
  @JavascriptInterface public void logout(){worker.submit(()->{api.logout();emit("account",JSONObject.NULL);emit("payments",new JSONArray());localStatus();});}
  @JavascriptInterface public void auth(){syncRemoteState();}
  @JavascriptInterface public void vip(String plan,String method,String reference){worker.submit(()->{try{JSONObject r=api.createPayment(plan,method,reference==null?"":reference.trim());emit("paymentCreated",r);emit("payments",api.payments());}catch(Exception e){error("Permintaan VIP gagal: "+safe(e));}});}
  @JavascriptInterface public void payments(){worker.submit(()->{try{emit("payments",api.payments());}catch(Exception e){error("Riwayat pembayaran gagal dimuat: "+safe(e));}});}

  @JavascriptInterface public void ownerUnlock(String pin){worker.submit(()->{try{JSONObject r=api.ownerUnlock(pin==null?"":pin);emit("ownerUnlocked",r);emit("ownerQueue",api.ownerQueue());}catch(Exception e){error("Akses owner ditolak: "+safe(e));}});}
  @JavascriptInterface public void ownerLock(){api.ownerLock();emit("ownerLocked","true");}
  @JavascriptInterface public void ownerQueue(){worker.submit(()->{try{emit("ownerQueue",api.ownerQueue());}catch(Exception e){error("Antrean owner gagal dimuat: "+safe(e));}});}
  @JavascriptInterface public void ownerDecision(String id,String decision,String note){worker.submit(()->{try{JSONObject r=api.ownerDecision(id,decision,note);emit("ownerDecision",r);emit("ownerQueue",api.ownerQueue());}catch(Exception e){error("Keputusan pembayaran gagal: "+safe(e));}});}
  @JavascriptInterface public void ownerGrant(String email,int days){worker.submit(()->{try{JSONObject r=api.ownerGrant(email,days);emit("ownerGrant",r);}catch(Exception e){error("Upgrade akun gagal: "+safe(e));}});}

  @JavascriptInterface public void trust(String pkg,boolean on){if(pkg==null||pkg.trim().isEmpty())return;security.setTrusted(pkg.trim(),on);localStatus();}
  @JavascriptInterface public void mode(String mode){
   if("standard".equals(mode)){security.mode("standard");localStatus();return;}
   requireEntitled(()->{security.mode(mode);localStatus();});
  }
  @JavascriptInterface public void history(){emit("history",security.history());}
  @JavascriptInterface public void syncThreats(){requireEntitled(()->worker.submit(()->{try{JSONObject envelope=api.threatFeed();JSONObject state=threatFeed.applyEnvelope(envelope.toString(),true);emit("threatFeed",state);localStatus();}catch(Exception e){error("Threat feed gagal diperbarui: "+safe(e));}}));}

  @JavascriptInterface public void isolate(String pkg,boolean on){
   if(!on){runOnUiThread(()->stopIsolation());return;}
   requireEntitled(()->runOnUiThread(()->prepareIsolation(pkg)));
  }
 }

 private void prepareIsolation(String pkg){
  if(pkg==null||pkg.trim().isEmpty()){error("Pilih aplikasi yang ingin diisolasi.");return;}
  try{getPackageManager().getPackageInfo(pkg,0);}catch(Exception e){error("Aplikasi tidak ditemukan.");return;}
  pendingVpnPackage=pkg;
  Intent prepare=VpnService.prepare(this);if(prepare!=null){launchFor(prepare,VPN);}else startIsolation(pkg);
 }
 private void startIsolation(String pkg){
  Intent i=new Intent(this,IsolationVpnService.class).setAction(IsolationVpnService.ACTION_START).putExtra(IsolationVpnService.EXTRA_PACKAGE,pkg);
  try{if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);emit("isolation",IsolationVpnService.status(this));new Handler(Looper.getMainLooper()).postDelayed(this::localStatus,500);}catch(Exception e){error("Isolasi jaringan gagal dimulai.");}
 }
 private void stopIsolation(){
  Intent i=new Intent(this,IsolationVpnService.class).setAction(IsolationVpnService.ACTION_STOP);
  try{startService(i);}catch(Exception e){stopService(new Intent(this,IsolationVpnService.class));}
  new Handler(Looper.getMainLooper()).postDelayed(this::localStatus,350);
 }

 private void launch(Intent i){try{startActivity(i);}catch(Exception e){error("Menu ini tidak tersedia di perangkat.");}}
 private void launchFor(Intent i,int code){try{startActivityForResult(i,code);}catch(Exception e){error("Aksi ini tidak tersedia di perangkat.");}}

 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
  if(request==VPN){String pkg=pendingVpnPackage;pendingVpnPackage=null;if(result==RESULT_OK&&pkg!=null)startIsolation(pkg);else error("Izin VPN diperlukan untuk mengisolasi jaringan aplikasi.");return;}
  if(result!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();
  if(request==EXPORT){worker.submit(()->{try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException();out.write(Scanner.load(this).getBytes("UTF-8"));emit("message",JSONObject.quote("Laporan tersimpan. Tinjau isinya sebelum dibagikan."));}catch(Exception e){error("Laporan gagal disimpan.");}});return;}
  if(request!=PICK||!busy.compareAndSet(false,true))return;emit("fileStart","true");worker.submit(()->{
   File tmp=null;try{tmp=File.createTempFile("selected-",".apk",getCacheDir());
    try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(tmp)){if(in==null)throw new IOException();byte[] b=new byte[65536];long size=0;int n;while((n=in.read(b))!=-1){if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();size+=n;if(size>Rules.MAX_BYTES)throw new IOException("Batas ukuran 512 MiB terlampaui");out.write(b,0,n);}}
    android.content.pm.PackageInfo p=getPackageManager().getPackageArchiveInfo(tmp.getPath(),Scanner.FLAGS);JSONObject row;
    if(p!=null&&p.applicationInfo!=null){p.applicationInfo.sourceDir=tmp.getPath();p.applicationInfo.publicSourceDir=tmp.getPath();row=new Scanner(this).inspect(p,false,true);}
    else{try(InputStream in=new FileInputStream(tmp)){String[] h=Rules.hashes(in);row=new JSONObject().put("label","File pilihan").put("pkg","").put("score",0).put("installed",false).put("findings",new JSONArray()).put("hashState","complete").put("formatNote","Bukan APK yang dapat dibaca. Hanya hash file diperiksa; isi arsip/dokumen tidak dianalisis.").put("hashes",new JSONArray().put(new JSONObject().put("sha256",h[0]).put("sha1",h[1])));String match=Rules.IOC.get(h[1]);if(match==null)match=Rules.remoteMatchSha256(h[0]);if(match!=null)row.put("malware",match).put("source",Rules.remoteMatchSha256(h[0])!=null?"Sentinel signed threat feed "+Rules.remoteVersion():Rules.SOURCE);}}
    emit("file",row);
   }catch(Exception e){error("File gagal dipindai: "+(e instanceof IOException?e.getMessage():"format atau akses tidak didukung"));}finally{if(tmp!=null)tmp.delete();busy.set(false);emit("idle","true");}
  });
 }

 @Override protected void onResume(){super.onResume();if(web!=null&&uiReady){localStatus();syncRemoteState();}}
 @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);localStatus();}
 @Override protected void onDestroy(){worker.shutdownNow();if(web!=null){web.removeJavascriptInterface("Sentinel");web.destroy();}super.onDestroy();}
}
