package store.ditz.sentinel;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.net.VpnService;
import android.os.*;
import org.json.JSONObject;
import java.io.*;

/**
 * Per-app network kill switch. Only the selected app is routed into this TUN and packets are dropped.
 * Other apps keep their normal network path. This is isolation, not HTTPS inspection and not a full VPN proxy.
 */
public final class IsolationVpnService extends VpnService {
 public static final String ACTION_START="store.ditz.sentinel.ISOLATE_START";
 public static final String ACTION_STOP="store.ditz.sentinel.ISOLATE_STOP";
 public static final String EXTRA_PACKAGE="package";
 private static final String PREF="sentinel_isolation";
 private ParcelFileDescriptor tun;private Thread drain;private volatile boolean running;

 public static boolean active(Context c){return c.getSharedPreferences(PREF,0).getBoolean("active",false);}
 public static String pkg(Context c){return c.getSharedPreferences(PREF,0).getString("pkg","");}
 public static JSONObject status(Context c){try{return new JSONObject().put("active",active(c)).put("pkg",pkg(c)).put("since",c.getSharedPreferences(PREF,0).getLong("since",0)).put("droppedBytes",c.getSharedPreferences(PREF,0).getLong("dropped",0));}catch(Exception e){return new JSONObject();}}

 @Override public int onStartCommand(Intent intent,int flags,int startId){
  if(intent==null)return START_NOT_STICKY;
  if(ACTION_STOP.equals(intent.getAction())){shutdown("Stopped by user");return START_NOT_STICKY;}
  if(!ACTION_START.equals(intent.getAction()))return START_NOT_STICKY;
  String pkg=intent.getStringExtra(EXTRA_PACKAGE);if(pkg==null||pkg.trim().isEmpty()){shutdown("No package");return START_NOT_STICKY;}
  startFg(pkg);if(!establishFor(pkg)){shutdown("Failed to establish");return START_NOT_STICKY;}return START_STICKY;
 }
 private void startFg(String pkg){
  NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.createNotificationChannel(new NotificationChannel("isolation","Sentinel Network Isolation",NotificationManager.IMPORTANCE_LOW));
  PendingIntent open=PendingIntent.getActivity(this,9,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
  Notification n=new Notification.Builder(this,"isolation").setSmallIcon(R.drawable.shield).setContentTitle("Sentinel · network isolated").setContentText(pkg+" tidak dapat mengakses jaringan selama isolasi aktif.").setOngoing(true).setContentIntent(open).build();
  if(Build.VERSION.SDK_INT>=34)startForeground(9002,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);else startForeground(9002,n);
 }
 private boolean establishFor(String pkg){
  closeTun();try{
   Builder b=new Builder().setSession("Sentinel isolation · "+pkg).setMtu(1500).addAddress("10.77.0.1",32).addRoute("0.0.0.0",0).addAddress("fd77::1",128).addRoute("::",0).addAllowedApplication(pkg);
   tun=b.establish();if(tun==null)return false;running=true;getSharedPreferences(PREF,0).edit().putBoolean("active",true).putString("pkg",pkg).putLong("since",System.currentTimeMillis()).putLong("dropped",0).apply();
   new SecurityStore(this).event("network_isolation",pkg,pkg,"Akses jaringan aplikasi diisolasi melalui VpnService kill switch","high");
   drain=new Thread(()->drainPackets(pkg),"sentinel-isolation");drain.start();return true;
  }catch(Exception e){return false;}
 }
 private void drainPackets(String pkg){long total=0;try(FileInputStream in=new FileInputStream(tun.getFileDescriptor())){byte[] buf=new byte[32767];while(running){int n=in.read(buf);if(n<0)break;total+=n;if((total&0xfffff)<32767)getSharedPreferences(PREF,0).edit().putLong("dropped",total).apply();}}catch(Exception ignored){}finally{getSharedPreferences(PREF,0).edit().putLong("dropped",total).apply();}}
 private void closeTun(){running=false;if(drain!=null)drain.interrupt();drain=null;if(tun!=null)try{tun.close();}catch(Exception ignored){}tun=null;}
 private void shutdown(String reason){String p=pkg(this);closeTun();getSharedPreferences(PREF,0).edit().putBoolean("active",false).putString("pkg","").apply();if(!p.isEmpty())new SecurityStore(this).event("network_isolation_end",p,p,reason,"info");stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}
 @Override public void onRevoke(){shutdown("VPN permission revoked");super.onRevoke();}
 @Override public void onDestroy(){closeTun();super.onDestroy();}
}
