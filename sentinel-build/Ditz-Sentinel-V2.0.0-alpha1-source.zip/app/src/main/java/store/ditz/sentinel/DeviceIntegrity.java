package store.ditz.sentinel;

import android.app.*;
import android.app.admin.DevicePolicyManager;
import android.content.*;
import android.content.pm.*;
import android.net.*;
import android.os.*;
import android.provider.Settings;
import org.json.*;
import java.io.*;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

/** Best-effort, documented integrity signals only. Missing signals are reported as unknown, never fabricated. */
public final class DeviceIntegrity {
 private final Context c;private final PackageManager pm;
 public DeviceIntegrity(Context context){c=context.getApplicationContext();pm=c.getPackageManager();}

 private Set<String> components(String key){Set<String> r=new HashSet<>();try{String value=Settings.Secure.getString(c.getContentResolver(),key);if(value!=null)for(String raw:value.split(":")){ComponentName n=ComponentName.unflattenFromString(raw);if(n!=null)r.add(n.getPackageName());}}catch(Exception ignored){}return r;}
 private String prop(String key){
  java.lang.Process p=null;try{p=new ProcessBuilder("/system/bin/getprop",key).redirectErrorStream(true).start();ByteArrayOutputStream b=new ByteArrayOutputStream();try(InputStream in=p.getInputStream()){byte[] buf=new byte[256];int n;while((n=in.read(buf))!=-1&&b.size()<2048)b.write(buf,0,n);}p.waitFor(700,TimeUnit.MILLISECONDS);return b.toString("UTF-8").trim();}catch(Exception e){return "";}finally{if(p!=null)p.destroy();}
 }
 private Boolean selinux(){try(BufferedReader r=new BufferedReader(new FileReader("/sys/fs/selinux/enforce"))){String s=r.readLine();if("1".equals(s))return true;if("0".equals(s))return false;}catch(Exception ignored){}return null;}
 private int patchAge(){try{String p=Build.VERSION.SECURITY_PATCH;if(p==null||p.isEmpty())return -1;SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setLenient(false);Date d=f.parse(p);return d==null?-1:(int)Math.max(0,(System.currentTimeMillis()-d.getTime())/86400000L);}catch(Exception e){return -1;}}
 private JSONArray rootSignals(){
  JSONArray a=new JSONArray();
  if(Build.TAGS!=null&&Build.TAGS.contains("test-keys"))a.put("Build tags memuat test-keys");
  String[] paths={"/system/bin/su","/system/xbin/su","/sbin/su","/system/app/Superuser.apk","/data/adb/magisk","/data/adb/ksu"};for(String p:paths)try{if(new File(p).exists())a.put("Artefak root terlihat: "+p);}catch(Exception ignored){}
  String[] pkgs={"com.topjohnwu.magisk","me.weishu.kernelsu","me.bmax.apatch"};for(String p:pkgs)try{pm.getPackageInfo(p,0);a.put("Manajer root terlihat: "+p);}catch(Exception ignored){}
  return a;
 }
 private String selfSigner(){try{PackageInfo p=pm.getPackageInfo(c.getPackageName(),PackageManager.GET_SIGNING_CERTIFICATES);if(p.signingInfo==null)return "";Signature[] sigs=p.signingInfo.getApkContentsSigners();if(sigs==null||sigs.length==0)return "";return Rules.hex(MessageDigest.getInstance("SHA-256").digest(sigs[0].toByteArray()));}catch(Exception e){return "";}}

 public JSONObject audit(){
  JSONObject j=new JSONObject();try{
   j.put("device",Build.MANUFACTURER+" "+Build.MODEL).put("android",Build.VERSION.RELEASE).put("sdk",Build.VERSION.SDK_INT).put("patch",Build.VERSION.SECURITY_PATCH).put("patchAgeDays",patchAge());
   j.put("screenLock",((KeyguardManager)c.getSystemService(Context.KEYGUARD_SERVICE)).isDeviceSecure());
   j.put("adb",Settings.Global.getInt(c.getContentResolver(),Settings.Global.ADB_ENABLED,0)==1);
   j.put("developerOptions",Settings.Global.getInt(c.getContentResolver(),Settings.Global.DEVELOPMENT_SETTINGS_ENABLED,0)==1);
   j.put("accessibility",new JSONArray(components("enabled_accessibility_services"))).put("notificationReaders",new JSONArray(components("enabled_notification_listeners")));
   DevicePolicyManager d=(DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);List<ComponentName> admins=d.getActiveAdmins();JSONArray aa=new JSONArray();if(admins!=null)for(ComponentName n:admins)aa.put(n.getPackageName());j.put("deviceAdmins",aa);
   if(Build.VERSION.SDK_INT>=28)j.put("privateDns",Settings.Global.getString(c.getContentResolver(),"private_dns_mode"));
   ConnectivityManager cm=(ConnectivityManager)c.getSystemService(Context.CONNECTIVITY_SERVICE);Network n=cm.getActiveNetwork();NetworkCapabilities nc=n==null?null:cm.getNetworkCapabilities(n);j.put("vpnActive",nc!=null&&nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN));
   String vb=prop("ro.boot.verifiedbootstate"),ds=prop("ro.boot.vbmeta.device_state"),fl=prop("ro.boot.flash.locked");j.put("verifiedBoot",vb.isEmpty()?JSONObject.NULL:vb).put("vbmetaState",ds.isEmpty()?JSONObject.NULL:ds).put("flashLocked",fl.isEmpty()?JSONObject.NULL:fl);
   Boolean se=selinux();j.put("selinuxEnforcing",se==null?JSONObject.NULL:se);
   j.put("rootSignals",rootSignals());
   String signer=selfSigner(),expected=c.getString(R.string.sentinel_expected_signer_sha256).trim();j.put("selfSigner",signer).put("selfSignerPin",expected.isEmpty()?"not_configured":(expected.equalsIgnoreCase(signer)?"match":"mismatch"));
   j.put("playProtectStatus","not_exposed_to_third_party_apps");
  }catch(Exception ignored){}
  return j;
 }
}
