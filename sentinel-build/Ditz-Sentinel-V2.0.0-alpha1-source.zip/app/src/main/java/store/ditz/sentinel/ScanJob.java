package store.ditz.sentinel;
import android.app.*;
import android.app.job.*;
import android.content.*;
import org.json.*;
import java.util.concurrent.*;

public final class ScanJob extends JobService {
 ExecutorService worker; Future<?> task; volatile boolean stopped; int activeJob;
 private static final String PREF="sentinel";
 public static boolean enabled(Context c){return c.getSharedPreferences(PREF,0).getBoolean("monitor",false);}
 public static boolean schedule(Context c,boolean on){
  JobScheduler scheduler=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
  if(!on){c.getSharedPreferences(PREF,0).edit().putBoolean("monitor",false).apply();scheduler.cancel(410);scheduler.cancel(411);return true;}
  int status=scheduler.schedule(new JobInfo.Builder(410,new ComponentName(c,ScanJob.class)).setPeriodic(6*60*60*1000L).setPersisted(true).setRequiresBatteryNotLow(true).build());
  boolean ok=status==JobScheduler.RESULT_SUCCESS;c.getSharedPreferences(PREF,0).edit().putBoolean("monitor",ok).apply();return ok;
 }
 public static void changed(Context c){if(enabled(c))((JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE)).schedule(new JobInfo.Builder(411,new ComponentName(c,ScanJob.class)).setMinimumLatency(3500).setOverrideDeadline(60_000).setRequiresBatteryNotLow(true).build());}
 @Override public boolean onStartJob(JobParameters params){
  if(!enabled(this)||task!=null&&!task.isDone())return false;activeJob=params.getJobId();stopped=false;worker=Executors.newSingleThreadExecutor();task=worker.submit(()->{
   try{JSONObject r=new Scanner(this).scan(true,(a,b,label)->{});if(stopped||!enabled(this))return;Scanner.save(this,r);
    String mode=new SecurityStore(this).mode();int threshold="lockdown".equals(mode)?15:"strict".equals(mode)?25:45;JSONArray rs=r.getJSONArray("results");int count=0,known=0;
    for(int i=0;i<rs.length();i++){JSONObject x=rs.getJSONObject(i);if(x.has("malware")){count++;known++;}else if(x.optInt("score")>=threshold&&!x.optBoolean("trusted",false))count++;}
    if(count>0)notifyUser(count,known,mode);
   }catch(Exception ignored){}finally{if(!stopped)jobFinished(params,false);if(worker!=null)worker.shutdown();}
  });return true;
 }
 void notifyUser(int count,int known,String mode){
  NotificationManager m=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);m.createNotificationChannel(new NotificationChannel("findings","Hasil pemeriksaan",NotificationManager.IMPORTANCE_DEFAULT));
  PendingIntent p=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
  String text=known>0?known+" kecocokan indikator malware. Buka Sentinel sekarang.":count+" aplikasi melewati ambang mode "+mode+" dan perlu ditinjau.";
  try{m.notify(1,new Notification.Builder(this,"findings").setSmallIcon(store.ditz.sentinel.R.drawable.shield).setContentTitle("Ditz Sentinel · tinjau keamanan").setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text)).setContentIntent(p).setAutoCancel(true).build());}catch(SecurityException ignored){}
 }
 @Override public boolean onStopJob(JobParameters params){if(params.getJobId()!=activeJob)return false;stopped=true;if(task!=null)task.cancel(true);if(worker!=null)worker.shutdownNow();return enabled(this);}
}
