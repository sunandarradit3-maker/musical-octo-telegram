package store.ditz.sentinel;

import android.content.*;
import android.net.Uri;
import android.os.Build;
import android.util.Base64;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;

/** Minimal HTTPS client for Sentinel account/VIP API. All device-security scans remain local. */
public final class ApiClient {
 private final Context c;private final SecureTokenStore store;private volatile String ownerToken;
 public ApiClient(Context context){c=context.getApplicationContext();store=new SecureTokenStore(c);}
 public static final class ApiException extends Exception {public final int status;ApiException(int s,String m){super(m);status=s;}}

 private String base()throws IOException{String b=c.getString(R.string.sentinel_api_base).trim();while(b.endsWith("/"))b=b.substring(0,b.length()-1);if(!b.startsWith("https://")||b.contains("CHANGE-ME"))throw new IOException("Backend Sentinel belum dikonfigurasi. Isi sentinel_api_base sebelum build.");return b;}
 public boolean configured(){try{base();return true;}catch(Exception e){return false;}}
 private static String b64url(byte[] x){return Base64.encodeToString(x,Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP);}
 private static String read(InputStream in)throws IOException{if(in==null)return "";try(InputStream x=in;ByteArrayOutputStream b=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n;while((n=x.read(buf))!=-1)b.write(buf,0,n);return b.toString("UTF-8");}}

 public String beginGoogleLogin()throws Exception{
  byte[] random=new byte[32];new SecureRandom().nextBytes(random);String verifier=b64url(random);String challenge=b64url(MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)));store.put("oauth_verifier",verifier);
  return base()+"/api/auth/google/start?challenge="+URLEncoder.encode(challenge,"UTF-8");
 }
 public JSONObject exchangeCallback(Uri uri)throws Exception{
  if(uri==null||!"ditzsentinel".equals(uri.getScheme())||!"auth".equals(uri.getHost()))throw new IOException("Callback login tidak valid.");String err=uri.getQueryParameter("error");if(err!=null)throw new IOException("Login Google dibatalkan atau ditolak: "+err);String code=uri.getQueryParameter("code"),verifier=store.get("oauth_verifier");if(code==null||verifier==null)throw new IOException("Kode login atau verifier tidak tersedia.");
  JSONObject body=new JSONObject().put("code",code).put("verifier",verifier).put("device",Build.MANUFACTURER+" "+Build.MODEL+" / Android "+Build.VERSION.RELEASE);JSONObject r=requestRaw("POST","/api/auth/exchange",body,null);saveSession(r);store.remove("oauth_verifier");return r.optJSONObject("account");
 }
 private void saveSession(JSONObject r){String a=r.optString("accessToken",null),f=r.optString("refreshToken",null);JSONObject account=r.optJSONObject("account");if(a!=null)store.put("access",a);if(f!=null)store.put("refresh",f);if(account!=null)store.put("account",account.toString());}
 private boolean refresh(){String token=store.get("refresh");if(token==null)return false;try{JSONObject r=requestRaw("POST","/api/auth/refresh",new JSONObject().put("refreshToken",token),null);saveSession(r);return r.has("accessToken");}catch(Exception e){store.clearSession();ownerToken=null;return false;}}

 private JSONObject request(String method,String path,JSONObject body,String authKind)throws Exception{
  String token=null;if("access".equals(authKind))token=store.get("access");else if("owner".equals(authKind))token=ownerToken;
  try{return requestRaw(method,path,body,token);}catch(ApiException e){if(e.status==401&&"access".equals(authKind)&&refresh())return requestRaw(method,path,body,store.get("access"));throw e;}
 }
 private JSONObject requestRaw(String method,String path,JSONObject body,String bearer)throws Exception{
  URL u=new URL(base()+path);HttpURLConnection h=(HttpURLConnection)u.openConnection();h.setConnectTimeout(12000);h.setReadTimeout(20000);h.setRequestMethod(method);h.setRequestProperty("Accept","application/json");h.setRequestProperty("User-Agent","Ditz-Sentinel/2.0 Android/"+Build.VERSION.SDK_INT);if(bearer!=null&&!bearer.isEmpty())h.setRequestProperty("Authorization","Bearer "+bearer);
  if(body!=null){h.setDoOutput(true);h.setRequestProperty("Content-Type","application/json; charset=utf-8");try(OutputStream out=h.getOutputStream()){out.write(body.toString().getBytes(StandardCharsets.UTF_8));}}
  int status=h.getResponseCode();String text=read(status>=200&&status<400?h.getInputStream():h.getErrorStream());JSONObject json;try{json=text.isEmpty()?new JSONObject():new JSONObject(text);}catch(Exception e){json=new JSONObject().put("raw",text);}
  if(status<200||status>=300){String msg=json.optString("error","Server mengembalikan status "+status);throw new ApiException(status,msg);}return json;
 }

 public JSONObject accountCached(){try{String x=store.get("account");return x==null?null:new JSONObject(x);}catch(Exception e){return null;}}
 public boolean isVipCached(){JSONObject a=accountCached();if(a==null)return false;if("OWNER".equals(a.optString("role")))return true;long until=a.optLong("vipUntilMs",0);if(until>0)return until>System.currentTimeMillis();return a.optBoolean("vipActive",false);}
 public JSONObject me()throws Exception{JSONObject r=request("GET","/api/me",null,"access");JSONObject a=r.optJSONObject("account");if(a!=null)store.put("account",a.toString());return a;}
 public JSONObject config()throws Exception{return request("GET","/api/config",null,null);}
 public JSONArray payments()throws Exception{return request("GET","/api/payments",null,"access").optJSONArray("payments");}
 public JSONObject createPayment(String plan,String method,String reference)throws Exception{return request("POST","/api/payments",new JSONObject().put("plan",plan).put("method",method).put("reference",reference),"access");}
 public JSONObject ownerUnlock(String pin)throws Exception{JSONObject r=request("POST","/api/owner/unlock",new JSONObject().put("pin",pin),"access");ownerToken=r.optString("ownerToken",null);return r;}
 public void ownerLock(){ownerToken=null;}
 public boolean ownerUnlocked(){return ownerToken!=null;}
 public JSONArray ownerQueue()throws Exception{return request("GET","/api/owner/payments",null,"owner").optJSONArray("payments");}
 public JSONObject ownerDecision(String id,String decision,String note)throws Exception{return request("POST","/api/owner/payments/"+URLEncoder.encode(id,"UTF-8")+"/decision",new JSONObject().put("decision",decision).put("note",note==null?"":note),"owner");}
 public JSONObject ownerGrant(String email,int days)throws Exception{return request("POST","/api/owner/users/grant",new JSONObject().put("email",email).put("days",days),"owner");}
 public JSONObject threatFeed()throws Exception{return request("GET","/api/threats/feed",null,"access");}
 public void logout(){String refresh=store.get("refresh");if(refresh!=null)try{requestRaw("POST","/api/auth/logout",new JSONObject().put("refreshToken",refresh),null);}catch(Exception ignored){}ownerToken=null;store.clearSession();}
}
