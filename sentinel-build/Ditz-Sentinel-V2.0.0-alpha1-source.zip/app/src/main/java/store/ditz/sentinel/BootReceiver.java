package store.ditz.sentinel;
import android.content.*;
public final class BootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){if(Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())&&ScanJob.enabled(c))ScanJob.schedule(c,true);}
}
