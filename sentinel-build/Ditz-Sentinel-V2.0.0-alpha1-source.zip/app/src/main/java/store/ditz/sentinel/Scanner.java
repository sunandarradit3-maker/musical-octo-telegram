package store.ditz.sentinel;

import android.content.*;
import android.content.pm.*;
import android.app.admin.DevicePolicyManager;
import android.provider.Settings;
import android.os.Build;
import org.json.*;
import java.io.*;
import java.util.*;

/** On-device package scanner. It never executes the inspected APK. */
public final class Scanner {
 final Context c; final PackageManager pm; final SecurityStore store;
 static final int FLAGS=PackageManager.GET_PERMISSIONS|PackageManager.GET_SERVICES|PackageManager.GET_SIGNING_CERTIFICATES;
 public Scanner(Context context){c=context.getApplicationContext();pm=c.getPackageManager();store=new SecurityStore(c);}
 public interface Progress{void update(int done,int total,String label);}
 public JSONObject scan(boolean deep,Progress progress)throws Exception{
  List<PackageInfo> pkgs=pm.getInstalledPackages(FLAGS); JSONArray results=new JSONArray();int i=0,failed=0,newApps=0,signerChanges=0,knownMatches=0;
  for(PackageInfo p:pkgs){
   if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();
   if(p.packageName.equals(c.getPackageName())){i++;continue;}
   try{
    JSONObject row=inspect(p,true,deep);results.put(row);
    String bs=row.optString("baseline","unchanged");if("new".equals(bs))newApps++;if("signer_changed".equals(bs))signerChanges++;if(row.has("malware"))knownMatches++;
   }catch(Exception e){failed++;results.put(new JSONObject().put("pkg",p.packageName).put("label",p.packageName).put("score",-1).put("error","Metadata tidak dapat dibaca").put("findings",new JSONArray()));}
   progress.update(++i,pkgs.size(),p.packageName);
  }
  JSONObject report=new JSONObject().put("time",System.currentTimeMillis()).put("deep",deep).put("results",results).put("failed",failed).put("newApps",newApps).put("signerChanges",signerChanges).put("knownMatches",knownMatches).put("mode",store.mode()).put("audit",audit());
  if(deep)store.commitBaseline(report);
  String severity=knownMatches>0||signerChanges>0?"high":(newApps>0?"info":"info");
  store.event("scan","","Sentinel scan",(deep?"Deep scan":"Quick audit")+": "+results.length()+" aplikasi, "+knownMatches+" hash match, "+signerChanges+" signer change",severity);
  return report;
 }
 public JSONObject inspect(PackageInfo p,boolean installed,boolean deep)throws Exception{
  Rules.Facts f=new Rules.Facts();f.installed=installed;f.pkg=p.packageName;
  ApplicationInfo ai=p.applicationInfo;if(ai==null)throw new IOException("Metadata aplikasi tidak lengkap");
  f.label=String.valueOf(ai.loadLabel(pm));f.target=ai.targetSdkVersion;f.system=(ai.flags&ApplicationInfo.FLAG_SYSTEM)!=0;f.debuggable=(ai.flags&ApplicationInfo.FLAG_DEBUGGABLE)!=0;
  long version=Build.VERSION.SDK_INT>=28?p.getLongVersionCode():p.versionCode;
  if(p.requestedPermissions!=null)for(int k=0;k<p.requestedPermissions.length;k++){
   f.requested.add(p.requestedPermissions[k]);if(installed&&p.requestedPermissionsFlags!=null&&k<p.requestedPermissionsFlags.length&&(p.requestedPermissionsFlags[k]&PackageInfo.REQUESTED_PERMISSION_GRANTED)!=0)f.granted.add(p.requestedPermissions[k]);
  }
  if(p.services!=null)for(ServiceInfo s:p.services){
   if("android.permission.BIND_ACCESSIBILITY_SERVICE".equals(s.permission))f.serviceAccessibility=true;
   if("android.permission.BIND_NOTIFICATION_LISTENER_SERVICE".equals(s.permission))f.serviceNotification=true;
   if("android.permission.BIND_VPN_SERVICE".equals(s.permission))f.vpnService=true;
  }
  if(installed){
   try{String name=Build.VERSION.SDK_INT>=30?pm.getInstallSourceInfo(p.packageName).getInstallingPackageName():pm.getInstallerPackageName(p.packageName);f.installer=name==null?"":name;}catch(Exception ignored){}
   f.accessibility=components("enabled_accessibility_services").contains(p.packageName);
   f.notification=components("enabled_notification_listeners").contains(p.packageName);
   try{DevicePolicyManager d=(DevicePolicyManager)c.getSystemService(Context.DEVICE_POLICY_SERVICE);List<ComponentName> admins=d.getActiveAdmins();if(admins!=null)for(ComponentName n:admins)if(n.getPackageName().equals(p.packageName))f.admin=true;}catch(Exception ignored){}
   f.hidden=pm.getLaunchIntentForPackage(p.packageName)==null;
  }
  JSONArray certificates=new JSONArray();String primarySigner="";
  if(p.signingInfo!=null){android.content.pm.Signature[] sigs=p.signingInfo.getApkContentsSigners();if(sigs!=null)for(android.content.pm.Signature s:sigs){String x=Rules.hex(java.security.MessageDigest.getInstance("SHA-256").digest(s.toByteArray()));if(primarySigner.isEmpty())primarySigner=x;certificates.put(x);}}
  String baseline=installed?store.baselineState(p.packageName,version,primarySigner):"not_applicable";f.signerChanged="signer_changed".equals(baseline);f.baselineNew="new".equals(baseline);
  List<Rules.Finding> findings=Rules.evaluate(f);JSONArray fs=new JSONArray();for(Rules.Finding q:findings)fs.put(new JSONObject().put("id",q.id).put("title",q.title).put("detail",q.detail).put("weight",q.weight));
  JSONObject out=new JSONObject().put("pkg",p.packageName).put("label",f.label).put("version",version).put("score",Rules.score(findings)).put("system",f.system).put("debuggable",f.debuggable).put("installed",installed).put("installer",f.installer).put("target",f.target).put("findings",fs).put("requested",new JSONArray(f.requested)).put("granted",new JSONArray(f.granted)).put("certificates",certificates).put("baseline",baseline).put("trusted",installed&&store.isTrusted(p.packageName)).put("hashState",deep?"pending":"not_scanned");
  if(deep){JSONArray hashes=new JSONArray();List<String> paths=new ArrayList<>();paths.add(ai.sourceDir);if(installed&&ai.splitSourceDirs!=null)Collections.addAll(paths,ai.splitSourceDirs);int errors=0;
   for(String path:paths){try(InputStream in=new FileInputStream(path)){
     String[] h=Rules.hashes(in);JSONObject entry=new JSONObject().put("file",new File(path).getName()).put("sha256",h[0]).put("sha1",h[1]).put("bytes",h[2]);
     String match=Rules.IOC.get(h[1]);String source=Rules.SOURCE;if(match==null){match=Rules.remoteMatchSha256(h[0]);source="Sentinel signed threat feed "+Rules.remoteVersion();}
     if(match!=null){entry.put("match",match);out.put("malware",match).put("source",source);}hashes.put(entry);
    }catch(InterruptedIOException e){throw e;}catch(Exception e){errors++;}}
   out.put("hashes",hashes).put("hashState",errors>0?"incomplete":"complete").put("hashErrors",errors);
  }
  return out;
 }
 Set<String> components(String key){Set<String> r=new HashSet<>();try{String value=Settings.Secure.getString(c.getContentResolver(),key);if(value!=null)for(String raw:value.split(":")){ComponentName n=ComponentName.unflattenFromString(raw);if(n!=null)r.add(n.getPackageName());}}catch(Exception ignored){}return r;}
 public JSONObject audit(){return new DeviceIntegrity(c).audit();}
 public static synchronized void save(Context c,JSONObject report)throws Exception{
  android.util.AtomicFile a=new android.util.AtomicFile(new File(c.getFilesDir(),"latest-v2.json"));FileOutputStream out=null;
  try{out=a.startWrite();out.write(report.toString().getBytes("UTF-8"));a.finishWrite(out);}catch(Exception e){if(out!=null)a.failWrite(out);throw e;}
 }
 public static synchronized String load(Context c){try(InputStream in=new FileInputStream(new File(c.getFilesDir(),"latest-v2.json"))){ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)b.write(buf,0,n);return b.toString("UTF-8");}catch(Exception e){return "null";}}
}
