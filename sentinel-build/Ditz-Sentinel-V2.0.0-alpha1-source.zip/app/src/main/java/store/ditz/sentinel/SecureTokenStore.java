package store.ditz.sentinel;

import android.content.*;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;

/** Small Android Keystore-backed encrypted preference store for session material. */
public final class SecureTokenStore {
 private static final String ALIAS="ditz_sentinel_v2_session";
 private final SharedPreferences prefs;
 public SecureTokenStore(Context c){prefs=c.getApplicationContext().getSharedPreferences("sentinel_secure_v2",0);}

 private SecretKey key()throws Exception{
  KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
  KeyStore.Entry e=ks.getEntry(ALIAS,null);if(e instanceof KeyStore.SecretKeyEntry)return ((KeyStore.SecretKeyEntry)e).getSecretKey();
  KeyGenerator g=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
  g.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
    .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build());
  return g.generateKey();
 }
 public synchronized void put(String name,String value){
  if(value==null){remove(name);return;}
  try{
   Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());byte[] enc=c.doFinal(value.getBytes(StandardCharsets.UTF_8));
   prefs.edit().putString(name+".iv",Base64.encodeToString(c.getIV(),Base64.NO_WRAP)).putString(name+".data",Base64.encodeToString(enc,Base64.NO_WRAP)).apply();
  }catch(Exception e){remove(name);}
 }
 public synchronized String get(String name){
  try{
   String iv=prefs.getString(name+".iv",null),data=prefs.getString(name+".data",null);if(iv==null||data==null)return null;
   Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(iv,Base64.NO_WRAP)));
   return new String(c.doFinal(Base64.decode(data,Base64.NO_WRAP)),StandardCharsets.UTF_8);
  }catch(Exception e){remove(name);return null;}
 }
 public synchronized void remove(String name){prefs.edit().remove(name+".iv").remove(name+".data").apply();}
 public synchronized void clearSession(){remove("access");remove("refresh");remove("account");remove("oauth_verifier");}
}
