package store.ditz.sentinel;
import java.util.*;
import java.io.*;
import java.security.*;
import java.net.*;

/** Pure deterministic rules. Findings prioritize review; they are not malware verdicts unless a known hash matches. */
public final class Rules {
 public static final long MAX_BYTES=512L*1024*1024;
 public static final String SOURCE="https://www.welivesecurity.com/en/eset-research/new-spyware-campaigns-target-privacy-conscious-android-users-uae/";
 public static final Map<String,String> IOC=new HashMap<>(); // published SHA-1 sample indicators kept for backwards compatibility
 public static final Set<String> DOMAINS=new HashSet<>(Arrays.asList("noblico.net","ai-messenger.co","spiralkey.co","store.latestversion.ai","store.appupdate.ai","totokupdate.ai","app-totok.io","signal.ct.ws","sgnlapp.info","encryption-plug-in-signal.com-ae.net","totokapp.info","totok-pro.io"));
 private static final Map<String,String> REMOTE_SHA256=new HashMap<>();
 private static final Set<String> REMOTE_DOMAINS=new HashSet<>();
 private static String remoteVersion="local-only";
 static {
  String[] to={"03fe2fcf66f86a75242f6112155134e66bc586cb","b22d58561bb64748f0d2e57b06282d6daf33cc68","bdc16a05bf6b771e6edb79634483c59fe041d59b","db9fe6cc777c68215bb0361139119dafee3b3194","de148ddfbf879ab2c12537ecccdd0541a38a8231","ce378ae427e4bd70eaaed204c51811cd74f9a294"};
  String[] pro={"7efeff53aaebf4b31bfcc093f2332944c3a6c0f6","154d67f871ffa19dce1a7646d5ae4ff00c509ee4","43f4dc193503947cb9449fe1cca8d3feb413a52d","579f9e5db2befccb61c833b355733c24524457ab","80ca4c48fa831cd52041bb1e353149c052c17481","ffaac2fdd9b6f5340d4202227b0b13e09f6ed031"};
  for(String h:to) IOC.put(h,"Android/Spy.ToSpy.A"); for(String h:pro) IOC.put(h,"Android/Spy.ProSpy.A");
 }
 public static final class Facts {
  public Set<String> requested=new HashSet<>(),granted=new HashSet<>();
  public boolean installed,accessibility,notification,admin,serviceAccessibility,serviceNotification,hidden,system,debuggable,vpnService,signerChanged,baselineNew;
  public int target=36; public String installer="",label="",pkg="";
 }
 public static final class Finding {
  public final String id,title,detail; public final int weight;
  Finding(String i,String t,String d,int w){id=i;title=t;detail=d;weight=w;}
 }
 static boolean has(Facts f,String p){return f.requested.contains("android.permission."+p);}
 private static boolean knownStore(String installer){return Arrays.asList("com.android.vending","com.google.android.packageinstaller","com.android.packageinstaller","com.miui.packageinstaller","com.sec.android.app.samsungapps","com.huawei.appmarket","com.oppo.market","com.vivo.appstore","com.transsion.phonemaster").contains(installer);}
 public static List<Finding> evaluate(Facts f){
  List<Finding> r=new ArrayList<>();
  if(f.signerChanged)r.add(new Finding("signer_changed","Penanda tangan aplikasi berubah","Sertifikat penanda tangan berbeda dari baseline Sentinel sebelumnya. Update normal umumnya mempertahankan signer; verifikasi sumber sebelum membuka aplikasi.",35));
  else if(f.baselineNew)r.add(new Finding("baseline_new","Aplikasi baru sejak baseline","Belum ada pada baseline scan mendalam sebelumnya. Ini informasi perubahan, bukan indikator malware.",0));
  if(f.accessibility)r.add(new Finding("accessibility","Aksesibilitas aktif","Dapat membaca elemen layar atau menjalankan tindakan. Pastikan fungsi ini memang diperlukan.",25));
  else if(f.serviceAccessibility)r.add(new Finding("accessibility_declared","Layanan aksesibilitas tersedia","Aplikasi mendeklarasikan layanan aksesibilitas; belum berarti akses sedang aktif.",0));
  if(f.notification)r.add(new Finding("notifications","Pembaca notifikasi aktif","Notifikasi dapat memuat pesan pribadi atau OTP. Periksa apakah akses ini sesuai fungsi aplikasi.",18));
  else if(f.serviceNotification)r.add(new Finding("notification_declared","Layanan pembaca notifikasi tersedia","Deklarasi kemampuan, bukan bukti akses aktif.",0));
  if(f.admin)r.add(new Finding("admin","Administrator perangkat aktif","Dapat menerapkan kebijakan perangkat. Cabut lewat Pengaturan bila aplikasi tidak dikenal.",18));
  if(has(f,"READ_SMS")||has(f,"RECEIVE_SMS"))r.add(new Finding("sms","Meminta akses SMS","Status izin runtime: "+(f.granted.contains("android.permission.READ_SMS")||f.granted.contains("android.permission.RECEIVE_SMS")?"diberikan":"belum diberikan / APK belum dipasang")+". Izin SMS sendiri bukan bukti malware.",10));
  if(has(f,"SYSTEM_ALERT_WINDOW"))r.add(new Finding("overlay","Meminta tampil di atas aplikasi","Overlay dapat dipakai untuk antarmuka sah maupun layar palsu. Status izin khusus perlu dicek di Pengaturan.",8));
  if(has(f,"REQUEST_INSTALL_PACKAGES"))r.add(new Finding("installer","Meminta memasang APK","Aplikasi dapat menawarkan pemasangan paket tambahan bila pengguna mengizinkan.",6));
  if(has(f,"MANAGE_EXTERNAL_STORAGE"))r.add(new Finding("storage","Meminta akses file luas","Periksa apakah akses ke seluruh file benar-benar diperlukan.",8));
  if(has(f,"REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"))r.add(new Finding("battery_bypass","Meminta pengecualian penghemat baterai","Dapat membantu aplikasi tetap aktif lebih lama di latar belakang. Wajar untuk sebagian aplikasi, namun perlu konteks.",4));
  if(has(f,"SCHEDULE_EXACT_ALARM")||has(f,"USE_EXACT_ALARM"))r.add(new Finding("exact_alarm","Meminta alarm presisi","Dapat membangunkan aplikasi pada waktu tertentu. Ini kemampuan, bukan diagnosis.",2));
  if(has(f,"RECEIVE_BOOT_COMPLETED"))r.add(new Finding("boot","Dapat aktif setelah boot","Aplikasi meminta notifikasi setelah perangkat menyala. Banyak aplikasi sah membutuhkannya.",2));
  if(has(f,"RECORD_AUDIO")&&has(f,"CAMERA")&&has(f,"ACCESS_FINE_LOCATION"))r.add(new Finding("sensors","Kombinasi mikrofon, kamera, lokasi","Kemampuan sensitif gabungan; aplikasi komunikasi juga sering membutuhkannya.",8));
  if(f.vpnService)r.add(new Finding("vpn","Mendeklarasikan layanan VPN","Layanan VPN dapat melihat metadata/lalu lintas yang melewatinya sesuai implementasi. Pastikan penyedianya dipercaya.",4));
  if(f.debuggable&&!f.system)r.add(new Finding("debuggable","Build aplikasi dapat di-debug","Flag debuggable aktif pada aplikasi non-sistem. Ini lazim pada build pengembangan, tidak ideal untuk rilis produksi.",8));
  if((f.accessibility||f.serviceAccessibility)&&has(f,"SYSTEM_ALERT_WINDOW")&&(has(f,"READ_SMS")||has(f,"RECEIVE_SMS")))r.add(new Finding("combo","Kombinasi akses berdaya tinggi","Aksesibilitas + overlay + SMS juga muncul pada pola pencurian akun. Tetap perlu bukti lain sebelum menyimpulkan malware.",25));
  if(f.accessibility&&has(f,"SYSTEM_ALERT_WINDOW"))r.add(new Finding("ui_control_combo","Aksesibilitas + overlay aktif/tersedia","Kombinasi ini dapat mengendalikan UI dan menampilkan lapisan di atas aplikasi lain. Verifikasi alasan penggunaannya.",12));
  if(f.accessibility&&has(f,"REQUEST_INSTALL_PACKAGES"))r.add(new Finding("install_control_combo","Aksesibilitas + pemasangan APK","Kombinasi ini memberi kemampuan interaksi UI sekaligus menawarkan instalasi paket lain. Tinjau sumber aplikasi.",10));
  if(f.notification&&(has(f,"READ_SMS")||has(f,"RECEIVE_SMS")))r.add(new Finding("otp_combo","Notifikasi + SMS","Aplikasi berpotensi melihat dua jalur pesan sensitif. Pastikan fungsi aplikasi membutuhkannya.",12));
  if(f.installed&&f.installer.isEmpty()&&!f.system)r.add(new Finding("origin","Sumber instalasi tidak tersedia","Bisa berasal dari sideload, pemulihan cadangan, ADB, atau pemasang yang tidak tercatat.",4));
  else if(f.installed&&!f.system&&!f.installer.isEmpty()&&!knownStore(f.installer))r.add(new Finding("origin_info","Sumber instalasi non-standar","Installer tercatat: "+f.installer+". Ini bukan otomatis berbahaya; verifikasi jika tidak dikenal.",0));
  if(f.hidden&&!f.system)r.add(new Finding("hidden","Tanpa ikon peluncur","Normal untuk plugin/service, tetapi layak dicek bila aplikasi tidak dikenal.",3));
  if(f.target<26)r.add(new Finding("legacy","Target Android sangat lama","Aplikasi menargetkan API di bawah 26 sehingga tidak mendapat banyak perilaku keamanan Android modern.",12));
  else if(f.target<30)r.add(new Finding("legacy","Target Android lama","Aplikasi menargetkan API di bawah 30. Periksa apakah ada versi lebih baru.",6));
  return r;
 }
 public static int score(List<Finding> fs){int n=0;for(Finding f:fs)n+=Math.max(0,f.weight);return Math.min(100,n);}
 public static String hex(byte[] b){StringBuilder s=new StringBuilder();for(byte v:b)s.append(String.format(Locale.ROOT,"%02x",v&255));return s.toString();}
 public static String[] hashes(InputStream in) throws Exception {
  MessageDigest a=MessageDigest.getInstance("SHA-256"),b=MessageDigest.getInstance("SHA-1");
  byte[] buf=new byte[65536]; long size=0; int n;
  while((n=in.read(buf))!=-1){if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("Dibatalkan");size+=n;if(size>MAX_BYTES)throw new IOException("File melebihi batas 512 MiB; scan tidak lengkap");a.update(buf,0,n);b.update(buf,0,n);}
  return new String[]{hex(a.digest()),hex(b.digest()),Long.toString(size)};
 }
 public static synchronized void setRemoteThreats(Map<String,String> sha256,Set<String> domains,String version){REMOTE_SHA256.clear();REMOTE_DOMAINS.clear();if(sha256!=null)REMOTE_SHA256.putAll(sha256);if(domains!=null)for(String d:domains)REMOTE_DOMAINS.add(d.toLowerCase(Locale.ROOT));remoteVersion=version==null?"remote":version;}
 public static synchronized String remoteMatchSha256(String h){return REMOTE_SHA256.get(h==null?"":h.toLowerCase(Locale.ROOT));}
 public static synchronized String remoteVersion(){return remoteVersion;}
 public static synchronized int remoteHashCount(){return REMOTE_SHA256.size();}
 public static synchronized int domainCount(){return DOMAINS.size()+REMOTE_DOMAINS.size();}
 private static synchronized boolean remoteDomain(String host){for(String d:REMOTE_DOMAINS)if(host.equals(d)||host.endsWith("."+d))return true;return false;}
 public static List<String> link(String input){
  List<String> r=new ArrayList<>();
  try{String s=input.trim();if(!s.matches("(?i)^[a-z][a-z0-9+.-]*://.*"))s="https://"+s;
   URI u=new URI(s);String host=u.getHost();if(host==null||!("https".equalsIgnoreCase(u.getScheme())||"http".equalsIgnoreCase(u.getScheme())))throw new Exception();
   host=IDN.toASCII(host).toLowerCase(Locale.ROOT);while(host.endsWith("."))host=host.substring(0,host.length()-1);
   boolean known=false;for(String d:DOMAINS)if(host.equals(d)||host.endsWith("."+d)){r.add("BAHAYA: domain cocok dengan indikator kampanye spyware publik yang dibundel Sentinel.");known=true;break;}
   if(!known&&remoteDomain(host)){r.add("BAHAYA: domain cocok dengan feed ancaman Sentinel yang telah diverifikasi tanda tangannya.");known=true;}
   if(u.getUserInfo()!=null)r.add("PERIKSA: ada bagian sebelum @; domain tujuan sebenarnya adalah "+host);
   if("http".equalsIgnoreCase(u.getScheme()))r.add("PERIKSA: koneksi HTTP tidak terenkripsi.");
   if(host.contains("xn--"))r.add("PERIKSA: domain memakai Punycode; periksa potensi kemiripan nama.");
   if(host.matches("[0-9.]+")||host.contains(":"))r.add("PERIKSA: alamat IP dipakai sebagai pengganti nama domain.");
   if(Arrays.asList("bit.ly","tinyurl.com","t.co","is.gd","cutt.ly").contains(host))r.add("PERIKSA: URL dipendekkan sehingga domain tujuan akhir belum terlihat.");
   if(r.isEmpty())r.add("BELUM ADA INDIKATOR: tidak cocok dengan database domain lokal/terverifikasi saat ini. Reputasi situs tetap belum diketahui; ini bukan jaminan aman.");
  }catch(Exception e){r.add("Format tautan tidak didukung. Masukkan URL HTTP/HTTPS dengan domain ASCII atau Punycode.");}
  return r;
 }
}
