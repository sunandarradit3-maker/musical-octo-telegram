package store.ditz.sentinel;
import android.content.*;
import android.net.Uri;
public final class InstallReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){
  String a=i.getAction();Uri d=i.getData();String pkg=d==null?"":d.getSchemeSpecificPart();
  if(Intent.ACTION_PACKAGE_ADDED.equals(a)||Intent.ACTION_PACKAGE_REPLACED.equals(a)||Intent.ACTION_PACKAGE_REMOVED.equals(a)){
   boolean replacing=i.getBooleanExtra(Intent.EXTRA_REPLACING,false);
   String type=Intent.ACTION_PACKAGE_REMOVED.equals(a)?"package_removed":(Intent.ACTION_PACKAGE_REPLACED.equals(a)||replacing?"package_updated":"package_added");
   new SecurityStore(c).event(type,pkg,pkg,type.replace('_',' '),"info");
   ScanJob.changed(c);
  }
 }
}
