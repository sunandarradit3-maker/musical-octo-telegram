package store.ditz.sentinel;

import android.content.Context;
import android.util.Base64;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;

/** Verifies ECDSA P-256 signed threat-feed envelopes before any remote IOC is trusted. */
public final class ThreatFeed {
 private final Context c;
 public ThreatFeed(Context context){c=context.getApplicationContext();}
 private PublicKey publicKey()throws Exception{
  String pem;try(InputStream in=c.getAssets().open("threat_feed_public.pem")){ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[2048];int n;while((n=in.read(x))!=-1)b.write(x,0,n);pem=b.toString("UTF-8");}
  String body=pem.replace("-----BEGIN PUBLIC KEY-----","").replace("-----END PUBLIC KEY-----","").replaceAll("\\s","");
  return KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(Base64.decode(body,Base64.DEFAULT)));
 }
 public synchronized JSONObject applyEnvelope(String envelope,boolean persist)throws Exception{
  JSONObject e=new JSONObject(envelope);String p64=e.getString("payload"),s64=e.getString("signature");byte[] payload=Base64.decode(p64,Base64.DEFAULT),sig=Base64.decode(s64,Base64.DEFAULT);
  Signature v=Signature.getInstance("SHA256withECDSA");v.initVerify(publicKey());v.update(payload);if(!v.verify(sig))throw new SecurityException("Tanda tangan feed ancaman tidak valid");
  JSONObject p=new JSONObject(new String(payload,StandardCharsets.UTF_8));String version=p.optString("version","");if(version.isEmpty())throw new SecurityException("Versi feed tidak tersedia");
  Map<String,String> hashes=new HashMap<>();JSONArray h=p.optJSONArray("sha256");if(h!=null)for(int i=0;i<h.length();i++){JSONObject x=h.optJSONObject(i);if(x==null)continue;String hash=x.optString("hash","").toLowerCase(Locale.ROOT),label=x.optString("label","Remote IOC");if(hash.matches("[a-f0-9]{64}"))hashes.put(hash,label);}
  Set<String> domains=new HashSet<>();JSONArray d=p.optJSONArray("domains");if(d!=null)for(int i=0;i<d.length();i++){String x=d.optString(i,"").toLowerCase(Locale.ROOT).trim();if(x.matches("[a-z0-9.-]+")&&!x.startsWith(".")&&!x.endsWith("."))domains.add(x);}
  Rules.setRemoteThreats(hashes,domains,version);if(persist)write(envelope);
  return new JSONObject().put("version",version).put("hashes",hashes.size()).put("domains",domains.size()).put("verified",true);
 }
 private void write(String value)throws Exception{File f=new File(c.getFilesDir(),"threat-feed-envelope.json");try(FileOutputStream out=new FileOutputStream(f)){out.write(value.getBytes(StandardCharsets.UTF_8));out.getFD().sync();}}
 private JSONObject localStatus(String error){JSONObject j=new JSONObject();try{j.put("version","local-only").put("hashes",0).put("domains",0).put("verified",false);if(error!=null&&!error.isEmpty())j.put("error",error);}catch(JSONException ignored){}return j;}
 public JSONObject loadCached(){try{File f=new File(c.getFilesDir(),"threat-feed-envelope.json");if(!f.exists())return localStatus(null);ByteArrayOutputStream b=new ByteArrayOutputStream();try(InputStream in=new FileInputStream(f)){byte[] x=new byte[4096];int n;while((n=in.read(x))!=-1)b.write(x,0,n);}return applyEnvelope(b.toString("UTF-8"),false);}catch(Exception e){return localStatus("Feed cache ditolak");}}
}
