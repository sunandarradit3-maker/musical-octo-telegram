import React from 'react'
export const metadata={title:'Ditz Sentinel V2 API',robots:{index:false,follow:false}}
export default function RootLayout({children}){return React.createElement('html',{lang:'id'},React.createElement('body',null,children))}
