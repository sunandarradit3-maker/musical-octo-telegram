import { db } from '@/lib/db.js'
import { requireUser, audit } from '@/lib/auth.js'
import { plans } from '@/lib/config.js'
import { bodyJson, json, errorResponse, cleanString } from '@/lib/http.js'
export const runtime='nodejs'
const methods=new Set(['QRIS','DANA','OVO','GOPAY'])
const mapRow=x=>({id:x.id,plan:x.plan_code,amount:Number(x.amount_idr),method:x.method,reference:x.sender_reference,status:x.status,note:x.owner_note,createdAt:new Date(x.created_at).toISOString(),decidedAt:x.decided_at?new Date(x.decided_at).toISOString():null})
export async function GET(req){try{const u=await requireUser(req);const r=await db().query('SELECT * FROM payment_requests WHERE user_id=$1 ORDER BY created_at DESC LIMIT 50',[u.id]);return json({payments:r.rows.map(mapRow)})}catch(e){return errorResponse(e)}}
export async function POST(req){
 try{
  const u=await requireUser(req), b=await bodyJson(req), plan=cleanString(b.plan,8), method=cleanString(b.method,16).toUpperCase(), reference=cleanString(b.reference,160)
  const spec=plans()[plan];if(!spec)throw Object.assign(new Error('Paket VIP tidak valid'),{status:400});if(!spec.price)throw Object.assign(new Error('Harga VIP belum dikonfigurasi owner'),{status:503});if(!methods.has(method))throw Object.assign(new Error('Metode pembayaran tidak valid'),{status:400});if(reference.length<2)throw Object.assign(new Error('Isi nama pengirim atau referensi pembayaran'),{status:400})
  const pending=await db().query("SELECT count(*)::int AS n FROM payment_requests WHERE status='PENDING'")
  const r=await db().query(`INSERT INTO payment_requests(user_id,plan_code,plan_days,amount_idr,method,sender_reference) VALUES($1,$2,$3,$4,$5,$6) RETURNING *`,[u.id,plan,spec.days,spec.price,method,reference])
  await audit(u.id,'payment_requested',{paymentId:r.rows[0].id,plan,method})
  return json({payment:mapRow(r.rows[0]),queuePosition:(pending.rows[0]?.n||0)+1,message:'Pembayaran masuk antrean verifikasi.'},201)
 }catch(e){return errorResponse(e)}
}
