import { db } from '@/lib/db.js'
import { bodyJson, json } from '@/lib/http.js'
import { sha256 } from '@/lib/security.js'
export const runtime='nodejs'
export async function POST(req){try{const b=await bodyJson(req);if(typeof b.refreshToken==='string')await db().query('UPDATE refresh_tokens SET revoked_at=COALESCE(revoked_at,now()) WHERE token_hash=$1',[sha256(b.refreshToken)]);}catch{}return json({ok:true})}
