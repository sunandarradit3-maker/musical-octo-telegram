import { db } from '@/lib/db.js'
import { ownerEmail, androidCallback } from '@/lib/config.js'
import { verifyToken, randomToken, sha256 } from '@/lib/security.js'
import { exchangeGoogleCode } from '@/lib/google.js'
import { audit } from '@/lib/auth.js'
export const runtime='nodejs'

function appRedirect(params){const u=new URL(androidCallback());for(const [k,v] of Object.entries(params))u.searchParams.set(k,v);return Response.redirect(u.toString(),302)}
export async function GET(req){
 try{
  const u=new URL(req.url), code=u.searchParams.get('code'), state=u.searchParams.get('state'), denied=u.searchParams.get('error')
  if(denied)return appRedirect({error:'google_denied'})
  if(!code||!state)return appRedirect({error:'missing_oauth_data'})
  let s;try{s=verifyToken(state,'oauth_state')}catch{return appRedirect({error:'invalid_state'})}
  const profile=await exchangeGoogleCode(code)
  const role=profile.email===ownerEmail()?'OWNER':'USER'
  const r=await db().query(`INSERT INTO users(google_sub,email,display_name,role,updated_at) VALUES($1,$2,$3,$4,now())
    ON CONFLICT (google_sub) DO UPDATE SET email=EXCLUDED.email,display_name=EXCLUDED.display_name,role=EXCLUDED.role,updated_at=now()
    RETURNING id,email,role`,[profile.sub,profile.email,profile.name,role])
  const user=r.rows[0], loginCode=randomToken(32)
  await db().query('INSERT INTO login_codes(code_hash,user_id,challenge,expires_at) VALUES($1,$2,$3,now()+interval \'2 minutes\')',[sha256(loginCode),user.id,s.challenge])
  await audit(user.id,'google_login_callback',{role:user.role})
  return appRedirect({code:loginCode})
 }catch(e){console.error('google callback',e);return appRedirect({error:'login_failed'})}
}
