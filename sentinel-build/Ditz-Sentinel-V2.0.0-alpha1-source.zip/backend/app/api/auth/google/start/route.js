import { googleAuthUrl } from '@/lib/google.js'
import { signToken, randomToken } from '@/lib/security.js'
export const runtime='nodejs'
export async function GET(req){
  const u=new URL(req.url), challenge=(u.searchParams.get('challenge')||'').trim()
  if(!/^[A-Za-z0-9_-]{43}$/.test(challenge)) return Response.json({error:'Invalid login challenge'},{status:400})
  const state=signToken({challenge,nonce:randomToken(18)},300,'oauth_state')
  return Response.redirect(googleAuthUrl(state),302)
}
