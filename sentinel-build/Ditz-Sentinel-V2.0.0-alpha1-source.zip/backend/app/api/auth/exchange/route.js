import { tx, db } from '@/lib/db.js'
import { bodyJson, json, errorResponse, cleanString } from '@/lib/http.js'
import { sha256, sha256b64url, randomToken, signToken } from '@/lib/security.js'
import { account, audit } from '@/lib/auth.js'
export const runtime='nodejs'
export async function POST(req){
 try{
  const b=await bodyJson(req), code=cleanString(b.code,256), verifier=cleanString(b.verifier,256), device=cleanString(b.device,256)
  if(!code||!/^[A-Za-z0-9_-]{43}$/.test(verifier))throw Object.assign(new Error('Invalid exchange request'),{status:400})
  const row=await tx(async c=>{
   const q=await c.query(`SELECT l.code_hash,l.user_id,l.challenge,l.expires_at,l.used_at,u.email,u.display_name,u.role,u.vip_until,u.created_at
     FROM login_codes l JOIN users u ON u.id=l.user_id WHERE l.code_hash=$1 FOR UPDATE`,[sha256(code)])
   if(!q.rowCount)throw Object.assign(new Error('Login code is invalid'),{status:401})
   const x=q.rows[0]
   if(x.used_at||new Date(x.expires_at).getTime()<Date.now()||sha256b64url(verifier)!==x.challenge)throw Object.assign(new Error('Login code expired or invalid'),{status:401})
   await c.query('UPDATE login_codes SET used_at=now() WHERE code_hash=$1',[x.code_hash])
   return {id:x.user_id,email:x.email,display_name:x.display_name,role:x.role,vip_until:x.vip_until,created_at:x.created_at}
  })
  const refresh=randomToken(48)
  await db().query('INSERT INTO refresh_tokens(token_hash,user_id,expires_at) VALUES($1,$2,now()+interval \'30 days\')',[sha256(refresh),row.id])
  const accessToken=signToken({sub:row.id},900,'access')
  await audit(row.id,'session_issued',{device})
  return json({accessToken,refreshToken:refresh,account:account(row)})
 }catch(e){return errorResponse(e)}
}
