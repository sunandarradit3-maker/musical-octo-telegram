import { tx } from '@/lib/db.js'
import { bodyJson, json, errorResponse, cleanString } from '@/lib/http.js'
import { sha256, randomToken, signToken } from '@/lib/security.js'
import { account } from '@/lib/auth.js'
export const runtime='nodejs'
export async function POST(req){
 try{
  const b=await bodyJson(req), old=cleanString(b.refreshToken,512);if(!old)throw Object.assign(new Error('Refresh token required'),{status:400})
  const replacement=randomToken(48)
  const user=await tx(async c=>{
   const q=await c.query(`SELECT r.token_hash,r.user_id,r.expires_at,r.revoked_at,u.email,u.display_name,u.role,u.vip_until,u.created_at
    FROM refresh_tokens r JOIN users u ON u.id=r.user_id WHERE r.token_hash=$1 FOR UPDATE`,[sha256(old)])
   if(!q.rowCount)throw Object.assign(new Error('Invalid refresh token'),{status:401})
   const x=q.rows[0];if(x.revoked_at||new Date(x.expires_at).getTime()<Date.now())throw Object.assign(new Error('Expired refresh token'),{status:401})
   await c.query('UPDATE refresh_tokens SET revoked_at=now() WHERE token_hash=$1',[x.token_hash])
   await c.query('INSERT INTO refresh_tokens(token_hash,user_id,expires_at) VALUES($1,$2,now()+interval \'30 days\')',[sha256(replacement),x.user_id])
   return {id:x.user_id,email:x.email,display_name:x.display_name,role:x.role,vip_until:x.vip_until,created_at:x.created_at}
  })
  return json({accessToken:signToken({sub:user.id},900,'access'),refreshToken:replacement,account:account(user)})
 }catch(e){return errorResponse(e)}
}
