import { requireUser, account } from '@/lib/auth.js'
import { json, errorResponse } from '@/lib/http.js'
export const runtime='nodejs'
export async function GET(req){try{return json({account:account(await requireUser(req))})}catch(e){return errorResponse(e)}}
