import fs from 'node:fs/promises'
import crypto from 'node:crypto'
import { requireUser } from '@/lib/auth.js'
import { json, errorResponse } from '@/lib/http.js'
export const runtime='nodejs'
export async function GET(req){
 try{
  const u=await requireUser(req), vip=u.role==='OWNER'||(u.vip_until&&new Date(u.vip_until).getTime()>Date.now());if(!vip)throw Object.assign(new Error('VIP required'),{status:403})
  const b64=process.env.THREAT_FEED_PRIVATE_KEY_B64?.trim();if(!b64)throw new Error('Threat feed signing key not configured')
  const source=JSON.parse(await fs.readFile(new URL('../../../../data/threats.json',import.meta.url),'utf8'))
  const payload=Buffer.from(JSON.stringify({version:String(source.version||new Date().toISOString()),sha256:Array.isArray(source.sha256)?source.sha256:[],domains:Array.isArray(source.domains)?source.domains:[]}),'utf8')
  const key=Buffer.from(b64,'base64').toString('utf8'), signature=crypto.sign('sha256',payload,key)
  return json({payload:payload.toString('base64'),signature:signature.toString('base64')})
 }catch(e){return errorResponse(e)}
}
