import { json } from '@/lib/http.js'
import { plans, paymentPublicConfig } from '@/lib/config.js'
export const runtime = 'nodejs'
export function GET(){
  const p=plans()
  return json({ plans:Object.values(p).map(x=>({code:x.code,label:x.label,days:x.days,price:x.price})), payment:paymentPublicConfig(), verification:'manual_queue' })
}
