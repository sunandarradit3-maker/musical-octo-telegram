import { json } from '@/lib/http.js'
export const runtime = 'nodejs'
export function GET(){ return json({ ok:true, service:'Ditz Sentinel V2 API', time:new Date().toISOString() }) }
