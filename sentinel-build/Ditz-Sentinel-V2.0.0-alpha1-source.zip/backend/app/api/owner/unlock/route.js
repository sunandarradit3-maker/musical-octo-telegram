import { db, tx } from '@/lib/db.js'
import { requireUser, audit } from '@/lib/auth.js'
import { verifyOwnerPin, signToken } from '@/lib/security.js'
import { bodyJson, json, errorResponse, cleanString } from '@/lib/http.js'
export const runtime='nodejs'
export async function POST(req){
 try{
  const u=await requireUser(req);if(u.role!=='OWNER')throw Object.assign(new Error('Owner account required'),{status:403})
  const state=await db().query('SELECT failed_attempts,locked_until FROM owner_pin_state WHERE user_id=$1',[u.id]);const s=state.rows[0]
  if(s?.locked_until&&new Date(s.locked_until).getTime()>Date.now())throw Object.assign(new Error('Owner PIN temporarily locked. Try again later.'),{status:429})
  const b=await bodyJson(req), pin=cleanString(b.pin,64), ok=verifyOwnerPin(pin)
  if(!ok){
   await tx(async c=>{await c.query(`INSERT INTO owner_pin_state(user_id,failed_attempts,locked_until,updated_at) VALUES($1,1,NULL,now()) ON CONFLICT(user_id) DO UPDATE SET failed_attempts=owner_pin_state.failed_attempts+1,updated_at=now()`,[u.id]);const q=await c.query('SELECT failed_attempts FROM owner_pin_state WHERE user_id=$1 FOR UPDATE',[u.id]);if((q.rows[0]?.failed_attempts||0)>=5)await c.query("UPDATE owner_pin_state SET failed_attempts=0,locked_until=now()+interval '15 minutes' WHERE user_id=$1",[u.id])})
   await audit(u.id,'owner_unlock_failed',{});throw Object.assign(new Error('PIN owner salah'),{status:401})
  }
  await db().query('INSERT INTO owner_pin_state(user_id,failed_attempts,locked_until,updated_at) VALUES($1,0,NULL,now()) ON CONFLICT(user_id) DO UPDATE SET failed_attempts=0,locked_until=NULL,updated_at=now()',[u.id])
  await audit(u.id,'owner_unlock_success',{})
  return json({ownerToken:signToken({sub:u.id},900,'owner'),expiresIn:900})
 }catch(e){return errorResponse(e)}
}
