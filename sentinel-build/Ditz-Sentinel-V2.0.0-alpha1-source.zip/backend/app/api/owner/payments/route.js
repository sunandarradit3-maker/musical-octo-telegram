import { db } from '@/lib/db.js'
import { requireOwner } from '@/lib/auth.js'
import { json, errorResponse } from '@/lib/http.js'
export const runtime='nodejs'
export async function GET(req){try{await requireOwner(req);const r=await db().query(`SELECT p.*,u.email,u.display_name FROM payment_requests p JOIN users u ON u.id=p.user_id ORDER BY (p.status='PENDING') DESC,p.created_at ASC LIMIT 100`);return json({payments:r.rows.map(x=>({id:x.id,email:x.email,name:x.display_name,plan:x.plan_code,days:x.plan_days,amount:Number(x.amount_idr),method:x.method,reference:x.sender_reference,status:x.status,note:x.owner_note,createdAt:new Date(x.created_at).toISOString()}))})}catch(e){return errorResponse(e)}}
