import { tx } from '@/lib/db.js'
import { requireOwner, audit, account } from '@/lib/auth.js'
import { bodyJson, json, errorResponse, cleanString } from '@/lib/http.js'
export const runtime='nodejs'
export async function POST(req,ctx){
 try{
  const owner=await requireOwner(req), {id}=await ctx.params, b=await bodyJson(req), decision=cleanString(b.decision,16).toUpperCase(), note=cleanString(b.note,500)
  if(!['APPROVE','REJECT'].includes(decision))throw Object.assign(new Error('Decision must be APPROVE or REJECT'),{status:400})
  const result=await tx(async c=>{
   const q=await c.query('SELECT * FROM payment_requests WHERE id=$1 FOR UPDATE',[id]);if(!q.rowCount)throw Object.assign(new Error('Payment request not found'),{status:404});const p=q.rows[0]
   if(p.status!=='PENDING')throw Object.assign(new Error('Payment request already decided'),{status:409})
   const status=decision==='APPROVE'?'APPROVED':'REJECTED'
   await c.query('UPDATE payment_requests SET status=$1,owner_note=$2,decided_by=$3,decided_at=now() WHERE id=$4',[status,note,owner.id,id])
   let user=null
   if(status==='APPROVED'){
    const u=await c.query(`UPDATE users SET vip_until=GREATEST(COALESCE(vip_until,now()),now()) + ($1::text || ' days')::interval,updated_at=now() WHERE id=$2 RETURNING id,email,display_name,role,vip_until,created_at`,[p.plan_days,p.user_id]);user=account(u.rows[0])
   }
   return {paymentId:id,status,user}
  })
  await audit(owner.id,'payment_decision',{paymentId:id,decision})
  return json(result)
 }catch(e){return errorResponse(e)}
}
