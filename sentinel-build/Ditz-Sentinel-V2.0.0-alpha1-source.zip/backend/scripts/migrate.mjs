import fs from 'node:fs/promises'
import pg from 'pg'
const { Client } = pg
if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required')
const sql = await fs.readFile(new URL('../sql/001_init.sql', import.meta.url), 'utf8')
const c = new Client({ connectionString: process.env.DATABASE_URL, ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : undefined })
await c.connect()
try { await c.query(sql); console.log('Sentinel database migration complete') } finally { await c.end() }
