import crypto from 'node:crypto'
let input = ''
for await (const chunk of process.stdin) input += chunk
const pin = input.trim()
if (pin.length < 4 || pin.length > 64) throw new Error('PIN must be 4-64 characters')
const N=16384,r=8,p=1,salt=crypto.randomBytes(16)
const digest=crypto.scryptSync(pin,salt,32,{N,r,p,maxmem:64*1024*1024})
console.log(`scrypt$${N}$${r}$${p}$${salt.toString('base64url')}$${digest.toString('base64url')}`)
