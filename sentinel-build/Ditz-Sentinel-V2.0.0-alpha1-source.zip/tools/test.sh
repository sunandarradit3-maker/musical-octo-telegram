#!/usr/bin/env bash
set -euo pipefail
root_dir="$(cd "$(dirname "$0")/.." && pwd)"
rm -rf "$root_dir/build/tests"
mkdir -p "$root_dir/build/tests"
javac --release 8 -d "$root_dir/build/tests" "$root_dir/app/src/main/java/store/ditz/sentinel/Rules.java" "$root_dir/tests/RulesTest.java"
java -cp "$root_dir/build/tests" store.ditz.sentinel.RulesTest
