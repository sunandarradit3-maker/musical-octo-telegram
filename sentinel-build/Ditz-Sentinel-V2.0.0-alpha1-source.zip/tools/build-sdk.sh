#!/usr/bin/env bash
set -euo pipefail
# Dependency-free Android client build using the official SDK only.
# SDK_HOME must contain platforms/android-36 and build-tools/36.0.0.
: "${SDK_HOME:?Set SDK_HOME to the Android SDK directory}"
root_dir="$(cd "$(dirname "$0")/.." && pwd)"
android_jar="$SDK_HOME/platforms/android-36/android.jar"
build_tools="$SDK_HOME/build-tools/36.0.0"
out_dir="$root_dir/build/manual"
for f in "$android_jar" "$build_tools/aapt2" "$build_tools/d8" "$build_tools/zipalign" "$build_tools/apksigner"; do
  [ -e "$f" ] || { echo "Missing Android SDK component: $f" >&2; exit 2; }
done
rm -rf "$out_dir"
mkdir -p "$out_dir/gen" "$out_dir/classes" "$out_dir/dex"
"$build_tools/aapt2" compile --dir "$root_dir/app/src/main/res" -o "$out_dir/resources.zip"
"$build_tools/aapt2" link -I "$android_jar" --manifest "$root_dir/app/src/main/AndroidManifest.xml" --java "$out_dir/gen" -A "$root_dir/app/src/main/assets" --min-sdk-version 26 --target-sdk-version 36 --version-code 20 --version-name 2.0.0-alpha1 -o "$out_dir/base.apk" "$out_dir/resources.zip"
find "$root_dir/app/src/main/java" "$out_dir/gen" -name '*.java' > "$out_dir/sources.txt"
javac --release 8 -encoding UTF-8 -classpath "$android_jar" -d "$out_dir/classes" @"$out_dir/sources.txt"
python3 - "$out_dir" <<'PY2'
import zipfile, pathlib, sys
p=pathlib.Path(sys.argv[1])
with zipfile.ZipFile(p/'classes.jar','w') as z:
 for f in (p/'classes').rglob('*.class'): z.write(f,f.relative_to(p/'classes'))
PY2
"$build_tools/d8" --lib "$android_jar" --min-api 26 --output "$out_dir/dex" "$out_dir/classes.jar"
python3 - "$out_dir" <<'PY2'
import zipfile,pathlib,sys,shutil
p=pathlib.Path(sys.argv[1]);shutil.copy(p/'base.apk',p/'unsigned.apk')
with zipfile.ZipFile(p/'unsigned.apk','a',zipfile.ZIP_DEFLATED) as z:
 for f in (p/'dex').glob('*.dex'):z.write(f,f.name)
PY2
"$build_tools/zipalign" -f -p 4 "$out_dir/unsigned.apk" "$out_dir/aligned.apk"
if [ -n "${SIGNING_KEYSTORE:-}" ]; then
 : "${SIGNING_ALIAS:?Set SIGNING_ALIAS}"
 "$build_tools/apksigner" sign --ks "$SIGNING_KEYSTORE" --ks-key-alias "$SIGNING_ALIAS" --out "$out_dir/Ditz-Sentinel-V2.apk" "$out_dir/aligned.apk"
 "$build_tools/apksigner" verify --verbose "$out_dir/Ditz-Sentinel-V2.apk"
else
 echo "Unsigned aligned APK: $out_dir/aligned.apk. Sign with your production keystore before installing."
fi
