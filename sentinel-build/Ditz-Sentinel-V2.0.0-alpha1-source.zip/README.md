# Ditz Sentinel V2

**Sentinel V2** is a local-first Android security control center by Ditz Store. V2 upgrades the original scanner into a zero-trust style architecture: on-device APK/package inspection, signer baselines, device-integrity signals, signed threat-intelligence updates, security history, Google-backed account identity, manual VIP entitlement, and a user-requested per-app network kill switch.

> Alpha software. Sentinel prioritizes visibility and reversible controls; it does not claim kernel-level antivirus access or 100% malware detection.

## What changed in V2

### On-device security core
- Deep scan of installed base APK + split APK files.
- SHA-256 and SHA-1 hashing with a hard 512 MiB scan bound.
- Local known-indicator matching plus remotely signed SHA-256/domain feeds.
- Signing-certificate fingerprints and drift detection against the last completed deep-scan baseline.
- Installer-source visibility and legacy target-SDK review.
- Permission-chain heuristics for Accessibility, notification access, SMS, overlays, APK install capability, Device Admin, broad file access, background persistence, and sensitive combinations.
- Device-integrity dashboard: patch level/age, screen lock, ADB, Developer Options, active Accessibility/notification readers, Device Admins, VPN presence, Verified Boot properties when readable, SELinux state, common root signals, and optional self-signer pinning.
- Security timeline for install/update/remove events, scans, trust changes, mode changes, and network-isolation events.
- Trusted-app decisions stored locally.
- Standard / Strict / Lockdown review profiles.
- Watchtower using Android JobScheduler, with event-triggered rescans after package changes.
- Offline link checks for bundled/verified threat domains, Punycode, HTTP, IP URLs, user-info spoofing, and common shorteners.

### VIP controls
- Per-app **network isolation** using Android `VpnService`: only the selected app is routed into a local TUN and its packets are dropped. Other apps keep their normal network path.
- Signed remote threat feed. Every feed envelope must verify against the ECDSA P-256 public key bundled in the APK before its indicators are loaded.
- Strict and Lockdown scan thresholds.

Network isolation is deliberately a kill switch, **not** HTTPS interception, TLS decryption, packet exfiltration, or a promise of system-wide firewall control.

### Account and owner system
- Google OAuth identity via the backend; the Android app does not embed a Google client secret.
- One-time login code protected with a device-generated verifier/challenge before tokens are issued to the app.
- Access token + rotating refresh token. Android stores session material encrypted with Android Keystore AES/GCM.
- User IDs are server-generated UUIDs.
- Owner identity requires both the verified owner Google account and a second PIN check.
- Owner PIN is stored only as a memory-hard scrypt hash on the backend. Five failed PIN attempts trigger a temporary lock.
- Owner console can approve/reject queued VIP requests or grant VIP days manually.
- Owner-elevation token lives only in process memory and expires after 15 minutes.

### VIP payment flow
- QRIS image is packaged into the app.
- DANA / OVO / GoPay destination comes from backend configuration.
- Users submit a payment method and sender/reference field.
- Requests enter a truthful **payment verification queue** with `PENDING`, `APPROVED`, or `REJECTED` state.
- VIP time is extended only after owner approval. Re-approving an already decided request is rejected transactionally.

Prices are intentionally not hard-coded in this repository. Configure `VIP_1M_PRICE` and `VIP_3M_PRICE` on the backend before accepting payments.

## Repository layout

```text
app/                       Android client (Java + local WebView UI)
  src/main/java/...        scanner, integrity, auth client, VPN isolation
  src/main/assets/ui/      local UI + packaged QRIS
  src/main/assets/         threat-feed verification public key
backend/                   Next.js API for auth, VIP, owner controls, signed feed
  app/api/                 route handlers
  lib/                     auth, crypto, Google OAuth, DB helpers
  sql/                     PostgreSQL schema
  data/threats.json        threat-feed source data to sign
  scripts/                 DB migration + owner PIN hashing
checks/                    generated validation output when packaged
docs/                      architecture, deployment, security notes
tests/                     deterministic Rules tests
tools/                     Android SDK-only build + tests
```

## Android configuration

Edit `app/src/main/res/values/config.xml` before a production build:

```xml
<string name="sentinel_api_base">https://YOUR-BACKEND.example</string>
<string name="sentinel_expected_signer_sha256">OPTIONAL_RELEASE_CERT_SHA256</string>
```

The app targets API 36 and has a minimum SDK of 26. Android client code intentionally has no third-party Java dependencies, so it can also be built using `tools/build-sdk.sh` when Android platform 36/build-tools 36.0.0 are installed.

### Gradle build

Open the root project in a recent Android Studio, or use a compatible Gradle installation:

```bash
gradle :app:assembleDebug
```

### SDK-only build

```bash
export SDK_HOME="$HOME/Android/Sdk"
./tools/build-sdk.sh
```

For a signed release, set `SIGNING_KEYSTORE` and `SIGNING_ALIAS`; never commit the keystore.

## Backend quick start

1. Provision PostgreSQL.
2. Create a Google OAuth **Web application** credential.
3. Add this authorized redirect URI:
   `https://YOUR-BACKEND/api/auth/google/callback`
4. Copy `backend/.env.example` to a private environment file and fill the required values.
5. Generate an owner PIN hash:
   `printf '%s' 'YOUR_PIN' | npm run hash-pin`
6. Install dependencies, migrate, and run:

```bash
cd backend
npm install
npm run migrate
npm run dev
```

For Vercel, add the same environment variables in Project Settings and deploy the `backend` directory as the project root. Keep `SESSION_SECRET`, `OWNER_PIN_HASH`, `GOOGLE_CLIENT_SECRET`, database credentials, and `THREAT_FEED_PRIVATE_KEY_B64` server-only.

## Threat-feed workflow

`backend/data/threats.json` contains the payload source. The backend signs the normalized JSON payload at request time with `THREAT_FEED_PRIVATE_KEY_B64`. The Android client verifies the signature with `app/src/main/assets/threat_feed_public.pem` before applying any remote IOC.

Never put the private signing key in the Android project or Git repository.

## Security and privacy boundaries

- Scan reports are stored on-device and are not automatically uploaded.
- The backend handles account identity, entitlement, payment requests, and signed feed delivery only.
- Sentinel does not request SMS, contacts, location, camera, microphone, root, or Accessibility access for itself.
- `QUERY_ALL_PACKAGES` is used because package visibility is core to the antivirus/security scanner function. Distribution stores may require a declaration/review for this permission.
- `VpnService` is user-consented and only activated for explicit per-app isolation.
- Android/ROM restrictions may make some integrity fields unavailable; missing data is shown as unknown, not guessed.

See `docs/ARCHITECTURE.md`, `docs/DEPLOYMENT.md`, and `SECURITY.md` for the detailed model.
