package store.ditz.sentinel;
import java.util.*;
import java.io.*;
public final class RulesTest {
 static int tests;
 static void check(boolean b,String name){tests++;if(!b)throw new AssertionError(name);System.out.println("PASS "+name);}
 public static void main(String[] args)throws Exception{
  Rules.Facts normal=new Rules.Facts();normal.installed=true;normal.installer="com.android.vending";
  check(Rules.score(Rules.evaluate(normal))==0,"No invented findings for empty facts");
  normal.requested.add("android.permission.CAMERA");check(Rules.score(Rules.evaluate(normal))==0,"Camera alone not labelled malware");
  Rules.Facts powerful=new Rules.Facts();powerful.serviceAccessibility=true;powerful.requested.addAll(Arrays.asList("android.permission.SYSTEM_ALERT_WINDOW","android.permission.READ_SMS"));
  check(Rules.score(Rules.evaluate(powerful))>=25,"Sensitive combination prioritized");
  check(Rules.evaluate(powerful).stream().anyMatch(f->f.id.equals("accessibility_declared")&&f.weight==0),"Declared accessibility not treated as active");
  check(Rules.evaluate(powerful).stream().noneMatch(f->f.id.equals("accessibility")),"No fabricated active permission");
  powerful.accessibility=true;check(Rules.evaluate(powerful).stream().anyMatch(f->f.id.equals("accessibility")),"Active access surfaced");
  powerful.admin=true;powerful.notification=true;powerful.target=22;check(Rules.score(Rules.evaluate(powerful))<=100,"Risk score capped");
  check(Rules.IOC.size()==12,"12 distinct malware IoCs");
  check("Android/Spy.ToSpy.A".equals(Rules.IOC.get("03fe2fcf66f86a75242f6112155134e66bc586cb")),"Published ToSpy indicator classification");
  check("Android/Spy.ProSpy.A".equals(Rules.IOC.get("154d67f871ffa19dce1a7646d5ae4ff00c509ee4")),"Published ProSpy indicator classification");
  String[] h=Rules.hashes(new ByteArrayInputStream("abc".getBytes("UTF-8")));
  check(h[0].equals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"),"SHA-256 known answer");
  check(h[1].equals("a9993e364706816aba3e25717850c26c9cd0d89d"),"SHA-1 known answer");
  check(h[2].equals("3"),"Hash byte count");
  check(!Rules.IOC.containsKey(h[1]),"Ordinary content not a known malware match");
  String[] empty=Rules.hashes(new ByteArrayInputStream(new byte[0]));check(empty[0].startsWith("e3b0c442"),"Empty file hashing");
  InputStream huge=new InputStream(){long n;public int read(){return 0;}public int read(byte[] b){if(n>Rules.MAX_BYTES)return -1;Arrays.fill(b,(byte)0);n+=b.length;return b.length;}};
  try{Rules.hashes(huge);throw new AssertionError("Size bound");}catch(IOException e){check(e.getMessage().contains("512"),"Oversize input rejected, never clean");}
  Thread.currentThread().interrupt();try{Rules.hashes(new ByteArrayInputStream(new byte[2]));throw new AssertionError();}catch(InterruptedIOException e){check(true,"Cancellation interrupts hashing");}finally{Thread.interrupted();}
  check(Rules.link("https://totok-pro.io").get(0).startsWith("BAHAYA"),"Exact malicious domain");
  check(Rules.link("https://a.totok-pro.io/path").get(0).startsWith("BAHAYA"),"Malicious subdomain");
  check(Rules.link("https://TOTOK-PRO.IO./").get(0).startsWith("BAHAYA"),"Domain case and trailing dot normalization");
  check(!Rules.link("https://totok-pro.io.example.org/").get(0).startsWith("BAHAYA"),"No suffix confusion");
  check(!Rules.link("https://nottotok-pro.io/").get(0).startsWith("BAHAYA"),"No substring false positive");
  check(Rules.link("https://totok-pro.io@example.org").stream().anyMatch(x->x.contains("sebelum @")),"Userinfo spoofing flagged");
  check(Rules.link("http://example.org").get(0).contains("HTTP"),"HTTP risk");
  check(Rules.link("https://127.0.0.1").get(0).contains("alamat IP"),"IP address risk");
  check(Rules.link("javascript:alert(1)").get(0).contains("tidak didukung"),"Unsupported scheme rejected");
  check(Rules.link("https://example.org").get(0).contains("bukan jaminan aman"),"Unknown domain never declared safe");
  Map<String,String> remote=new HashMap<>();remote.put("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","Remote.Test");Set<String> remoteDomains=new HashSet<>();remoteDomains.add("bad.example");Rules.setRemoteThreats(remote,remoteDomains,"test-v1");
  check("Remote.Test".equals(Rules.remoteMatchSha256("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")),"Remote SHA-256 feed applied");
  check(Rules.link("https://sub.bad.example/path").get(0).startsWith("BAHAYA"),"Remote signed-domain rule surfaced after verification layer");
  check("test-v1".equals(Rules.remoteVersion()),"Remote feed version retained");
  System.out.println("TOTAL: "+tests+" passed");
 }
}
